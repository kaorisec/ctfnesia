Description:
I believe that CTF player is much better than usual Sandiman!

format
hctf{________}

Hint:
How about think simple and see what kind of encryption it is?