Description:
Looks like we forgot to hid somethin

format
hctf{________}

Hint:
