Description:
Crack it and it's yours

Hint:
