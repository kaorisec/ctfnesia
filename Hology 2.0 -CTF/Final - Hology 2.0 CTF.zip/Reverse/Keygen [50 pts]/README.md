Description:
Reverse it and it's yours

34.87.0.60:14043

Hint:
