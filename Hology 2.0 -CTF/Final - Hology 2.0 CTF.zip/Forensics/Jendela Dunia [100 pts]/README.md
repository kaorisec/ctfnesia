Description:
there's somethin rotted.

becareful, it may lead urs to be overwritten.

Hint:
1. Displaying Opened Application in Jendela