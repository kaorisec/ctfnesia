Description:
Pwn it and it's yours

nc 34.87.0.60 14040

Hint:
