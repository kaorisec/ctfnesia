Description:
Pwn it and its yours!

nc 34.87.0.60 14041

Hint:
