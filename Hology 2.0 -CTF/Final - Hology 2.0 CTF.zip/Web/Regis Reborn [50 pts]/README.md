Description:
It's reborn

http://34.87.0.60:14045/

Hint:
