# Edit Your Source [244 pts]

**Category:** Web
**Solves:** 32

## Description
>No need to inspect element to fool your friends!

`http://3.0.19.78:15002`

Author: didithilmy

**Hint**
* 

## Solution

### Flag

