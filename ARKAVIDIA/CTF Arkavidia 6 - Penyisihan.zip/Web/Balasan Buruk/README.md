# Balasan Buruk [344 pts]

**Category:** Web
**Solves:** 23

## Description
>Saya baru saja belajar mata kuliah Jaringan Komputer, sebagai Tugas Besar, saya ditugaskan untuk membuat HTTP server sederhana tanpa menggunakan library HTTP apapun.

`http://3.0.19.78:15001`

Author: didithilmy

**Hint**
* 

## Solution

### Flag

