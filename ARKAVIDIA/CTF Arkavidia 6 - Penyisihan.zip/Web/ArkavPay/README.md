# ArkavPay [491 pts]

**Category:** Web
**Solves:** 7

## Description
>*There's a new fintech player in town!*

Katanya sih aman, tapi ternyata seorang hekelmen berhasil membocorkan sebagian source code ArkavPay.
[Source code](https://drive.google.com/open?id=1M1a0vUFhtAGg0USZUdwnqSsNau7t6XSa)

`http://18.141.24.237:14000`

Author: didithilmy

**Hint**
* 

## Solution

### Flag

