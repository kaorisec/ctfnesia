# Free Flag [25 pts]

**Category:** Misc
**Solves:** 86

## Description
>Flagnya ada di Discord gan!

[Link Discord](https://discord.gg/BcxZcC8)

**Hint**
* 

## Solution

### Flag

