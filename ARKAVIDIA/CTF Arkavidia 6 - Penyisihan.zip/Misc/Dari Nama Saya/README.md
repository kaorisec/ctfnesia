# Dari Nama Saya [50 pts]

**Category:** Misc
**Solves:** 35

## Description
>![Man digging](/files/cb3bfa4d12cdae7a48e905c10499f166/digging.jpg)

**Hint**
* 

## Solution

### Flag

