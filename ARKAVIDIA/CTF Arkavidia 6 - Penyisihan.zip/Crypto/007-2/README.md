# 007-2 [500 pts]

**Category:** Crypto
**Solves:** 0

## Description
>007: "Who even made this junk? RIP security..."

`nc 18.141.24.237 10007`

Format flag: Arkav6{}

[Attachment](https://drive.google.com/open?id=1TOtxrec68_YqT0IM_Mkl4H0AKvIsvdsn)

Author: nightmare

**Hint**
* 

## Solution

### Flag

