# 007-1 [498 pts]

**Category:** Crypto
**Solves:** 2

## Description
>007 in charge, what could possibly go wrong?

`nc 18.141.24.237 10006`

[Attachment](https://drive.google.com/open?id=1FlPJi9m_HCyzNalEQNe8Qex7ZystJ2i9)

Author: nightmare

**Hint**
* 

## Solution

### Flag

