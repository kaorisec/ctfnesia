# Baby Gauss RSA [500 pts]

**Category:** Crypto
**Solves:** 0

## Description
>Istri dari Professor Gaussian baru saja melahirkan seorang bayi yang diberi nama Gaussian Integer. Seorang bayi prodigy bernama Gaussian Integer ini sangatlah skeptis, sehingga setiap kali berbicara pesannya selalu dienkripsi dengan RSA. Sang Professor pun memberikan sayembara bahwa bagi siapa saja yang bisa menerjemahkan pesan dari bayi tersebut, maka professor akan memberikan hadiah berupa sebuah flag.

`nc 18.141.24.237 10005`

- Hint: Euler phi gaussian integer

Author: nicholaz99

**Hint**
* 

## Solution

### Flag

