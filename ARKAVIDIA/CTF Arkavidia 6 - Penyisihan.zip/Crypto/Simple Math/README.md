# Simple Math [500 pts]

**Category:** Crypto
**Solves:** 0

## Description
>Seorang professor matematika sangatlah suka teka - teki bersama muridnya. Pada suatu hari, sang professor memberikan teka-teki kepada muridnya. Sang murid diberikan beberapa clue terkait sebuah string secret yang harus ditebak oleh muridnya. Jikalau benar, maka sang Professor akan memberikan hadiah kepada murid tersebut. Tentu saja teka-teki yang diberikan menguji kemampuan matematika murid - muridnya :D.

`nc 18.141.24.237 10004`

[Attachment](https://drive.google.com/open?id=1yTGzyGHxdAQ4W9KhhCIdrp-qnhzZB8aJ)

Hint: Nama professor tersebut adalah Fermat :D <br/>

Author: nicholaz99

**Hint**
* 

## Solution

### Flag

