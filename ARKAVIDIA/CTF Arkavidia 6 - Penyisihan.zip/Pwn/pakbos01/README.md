# pakbos01 [458 pts]

**Category:** Pwn
**Solves:** 13

## Description
>`nc 3.0.19.78 10001`

[Attachment](https://drive.google.com/open?id=1QErUeKY3TJJVVSXdmXYIPzK2hFZF19t4)

Author: fraglantia

**Hint**
* 

## Solution

### Flag

