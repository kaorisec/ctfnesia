# pakbos02 [494 pts]

**Category:** Pwn
**Solves:** 6

## Description
>`nc 3.0.19.78 10002`

[Attachment](https://drive.google.com/open?id=1dkeuCDlahQOhEqPSyU-WcsNSbsPtl1PS)

Author: fraglantia

**Hint**
* 

## Solution

### Flag

