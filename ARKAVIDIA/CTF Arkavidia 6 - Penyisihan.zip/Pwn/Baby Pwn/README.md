# Baby Pwn [500 pts]

**Category:** Pwn
**Solves:** 1

## Description
>`nc 3.0.19.78 10003`

[Attachment](https://drive.google.com/open?id=1NuAT0HcqE6QgO2cyNSTdjQNlmzhdaKV_)

Author: djavaa

**Hint**
* 

## Solution

### Flag

