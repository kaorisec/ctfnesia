# 1001 Malam [500 pts]

**Category:** Reverse
**Solves:** 1

## Description
>Can you run this library?

[Attachment](https://drive.google.com/open?id=1Qiqh0caqdLO9XAb-ajOCYs25jjgQ3FWy)

- Note: Jangan ubah nama library
- Hint: Delphi 7, Common Hash Algorithm

Author: djavaa

**Hint**
* 

## Solution

### Flag

