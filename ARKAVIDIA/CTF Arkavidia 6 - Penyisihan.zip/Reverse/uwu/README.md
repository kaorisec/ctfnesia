# uwu [290 pts]

**Category:** Reverse
**Solves:** 28

## Description
>Can you crack me, plz?

[Attachment](https://drive.google.com/open?id=1Vx69kZ_rLD_a1LYaVwb36aY3ZKbi_wnP)

Author : alphaville

**Hint**
* 

## Solution

### Flag

