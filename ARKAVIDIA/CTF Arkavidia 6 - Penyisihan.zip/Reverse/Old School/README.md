# Old School [500 pts]

**Category:** Reverse
**Solves:** 0

## Description
>Hmm, found old program. Can you crack it?

[Attachment](https://drive.google.com/open?id=1_OROdqdUYgiXuA21k-LiK9pzUonvWze9)

Author: djavaa

**Hint**
* 

## Solution

### Flag

