# 멋지게 인사하는 법 [500 pts]

**Category:** Forensics
**Solves:** 0

## Description
>Dikarenakan sudah banyak soal sulit, akhirnya dibuat soal 'e-a-s-y' untuk Anda!

Buktikan kehebatan kemampuan forensics tim Anda!

[Attachment](https://drive.google.com/open?id=122PjCkf-ZZQURaSE3kzMoxZcP-L6-d0r)

- Note: Format flag Arkav6{}
- Hint: Soal ini bukan steganography (tidak perlu stego tools) dan tidak perlu bruteforce password zip sama sekali!
- Hint: Mungkin PNG-nya corrupted? Tapi kok kelihatan normal?

Author: haverzard

**Hint**
* 

## Solution

### Flag

