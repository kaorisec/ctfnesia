# Patriot [410 pts]

**Category:** Forensics
**Solves:** 13

## Description
>Munir menerima email yang dia tak mengerti. Bantulah Munir mengetahui apa isinya!

[Attachment](https://drive.google.com/open?id=1xnBmCtgrqOkfEMhgiXBsy7tyUVuqWkhj)

Author: didithilmy

**Hint**
* 

## Solution

### Flag

