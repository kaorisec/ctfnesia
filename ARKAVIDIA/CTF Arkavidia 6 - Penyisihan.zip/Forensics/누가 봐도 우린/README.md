# 누가 봐도 우린 [500 pts]

**Category:** Forensics
**Solves:** 0

## Description
>Baek-hyun memiliki sebuah backup files dari Server <b>Arkavidia 6</b> yang berisi IPv6 address server yang terenkripsi dan diubah dalam bentuk hex. Lucunya, Baek-hyun memperoleh backup tersebut pada dimensi lain sehingga header waktunya berbeda dengan aslinya dan tapenya corrupted!

Dengan bantuan gambar yang merepresentasikan dimensi waktu (luas objek tidak presisi) Baek-hyun dan kita, perbaiki disk tersebut dan perolehlah IPv6 address tersebut untuk kita DDoS!

[Attachment](https://drive.google.com/open?id=16e3AQPlRoQlGx9Q7DFRbWqGpvtS8NE5F)

- Note: Format flag Arkav6{}
- Hint: Enkripsi yang dilakukan sebenarnya bukan enkripsi, tetapi suatu proses decoding pada IPv6.
- Hint: RFC 1924

Author: haverzard

**Hint**
* 

## Solution

### Flag

