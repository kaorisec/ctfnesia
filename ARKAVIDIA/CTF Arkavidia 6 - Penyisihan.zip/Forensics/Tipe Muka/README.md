# Tipe Muka [100 pts]

**Category:** Forensics
**Solves:** 64

## Description
>Fahmi merupakan penggiat UI/UX yang sudah cukup berpengalaman. 
Pada suatu hari, dia sedang bosan dan memutuskan untuk mencoba hal baru, yaitu membuat font.
Setelah 4 jam mencoba, dia menyerah karena ternyata membuat font susah. Dia kemudian mengambil font yang open source dengan nama Source Sans Pro, memodifikasinya sedikit, kemudian mengganti namanya menjadi Arkav Sans.

[Attachment](https://drive.google.com/open?id=1WbhLq1gX0luhAIYVaEyUeYSwAiUxCO6-)

Author: didithilmy

**Hint**
* 

## Solution

### Flag

