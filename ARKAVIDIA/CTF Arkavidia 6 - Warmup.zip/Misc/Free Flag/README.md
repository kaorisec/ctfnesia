# Free Flag [1 pts]

**Category:** Misc
**Solves:** 33

## Description
>Masukin aja gan

Arkav6{c0ntoh_fl4g}

**Hint**
* 

## Solution

### Flag

