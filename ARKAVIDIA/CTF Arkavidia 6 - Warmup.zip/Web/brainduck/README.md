# brainduck [100 pts]

**Category:** Web
**Solves:** 2

## Description
>http://54.169.181.206:10000

**Hint**
* 

## Solution

### Flag

