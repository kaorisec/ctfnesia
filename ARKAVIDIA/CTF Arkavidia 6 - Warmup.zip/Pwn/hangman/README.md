# hangman [100 pts]

**Category:** Pwn
**Solves:** 1

## Description
>`nc 54.169.181.206 10001`

**Hint**
* 

## Solution

### Flag

