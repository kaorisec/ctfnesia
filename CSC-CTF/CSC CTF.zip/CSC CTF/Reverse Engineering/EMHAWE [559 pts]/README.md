Description:
It looks fine, but I think my code is broken :((

P.S. Please submit flag with `CCC{...}` format

author: NeXT

Hint:
