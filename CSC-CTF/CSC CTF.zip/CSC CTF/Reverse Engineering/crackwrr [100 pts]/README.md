Description:
Cracker jahat adalah h4ckwr baik yang tersakiti.....

author: redspiracy

Hint:
