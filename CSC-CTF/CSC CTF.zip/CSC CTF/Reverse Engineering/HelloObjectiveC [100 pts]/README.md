Description:
Please submit flag with `CCC{...}` format.

author: avltree9798

Hint:
