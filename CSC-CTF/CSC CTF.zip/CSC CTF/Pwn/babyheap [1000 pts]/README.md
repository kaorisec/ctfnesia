Description:
`nc babyheap.problem.cscctf.com 11113`

author: stürmisch

Hint:
`smallbin consolidation`