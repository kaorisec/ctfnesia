Description:
`nc babystack.problem.cscctf.com 11111`


author: stürmisch

Hint:
