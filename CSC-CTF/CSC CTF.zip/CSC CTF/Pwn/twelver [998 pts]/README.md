Description:
`nc twelver.problem.cscctf.com 11114`

author: stürmisch

Hint:
