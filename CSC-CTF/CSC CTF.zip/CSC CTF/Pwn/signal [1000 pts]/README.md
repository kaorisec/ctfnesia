Description:
`nc signal.problem.cscctf.com 11112`

author: stürmisch

Hint:
`__libc_csu_init`