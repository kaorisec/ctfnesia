Description:
True randomness in computer is hard.

`nc weakrandom.problem.cscctf.com 10000`

author: EternalBeats

Hint:
