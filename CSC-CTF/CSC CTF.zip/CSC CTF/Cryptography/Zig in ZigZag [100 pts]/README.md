Description:
Zig lost his partner in a room with X x Y unit. Zag is at the bottom right of the room. Follow Zig's journey of finding his partner Zag, and Zig will tell you the secret.

`WbiushCTneoebFppelpAHiaodMdtilaelehsasnDOashnegrcmeTvKYeftAoddZIoWrheiocQhndHSismhIeTnuiuemAaopNeesCodFpesalvHpoTrUoDOihettgeeitoesmefndriioTrnTTZepcPrOTocroegohideipouhnsiBIToigAtihbtiWMteshHsZndtelHshehCTeaPagYoreoKetmohZrroCorTmwirhMmeid`

P.S. Please submit the flag in `CCC{...}` format.

Hint:
