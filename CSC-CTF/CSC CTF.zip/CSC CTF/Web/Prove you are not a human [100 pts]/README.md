Description:
http://proveyouarenotahuman.problem.cscctf.com:9001/

author: Siahaan

Hint:
