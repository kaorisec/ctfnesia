Description:
Si Budi Kecil mendapat tautan misterius di surat elektronik miliknya.
Ketika dibuka, Si Budi Kecil menemukan sebuah file rahasia yang dicompress.
"Siapapun yang bisa memecahkan misteri yang ada di dalam file ini saya
nyatakan sebagai Master Trainee Android Forensic Analyst/Pentester", begitu pesan yang didapatkan berikut tautan tersebut.
Si Budi Kecil mengupload file tersebut ke dalam [dropbox](https://www.dropbox.com/s/5jza1dsuzms83qt/avd.zip?dl=0).

Dapatkah anda menjadi Master Trainee Android Forensic Analyst/Pentester?

P.S. File size is 600MB.
P.P.S. Please submit flag with `CCC{...}` format.

author: takaya

Hint:
