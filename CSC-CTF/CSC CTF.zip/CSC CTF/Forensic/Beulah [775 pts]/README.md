Description:
Bersatu kita teguh, bercerai kita [corrupted](https://www.dropbox.com/s/askov9rvzkvgpnb/chall.pcapng?dl=0).

author: Bigby

Hint:
