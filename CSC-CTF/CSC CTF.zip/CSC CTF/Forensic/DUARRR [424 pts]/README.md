Description:
Indonesia telah memasuki tahun 2027, ASEAN telah membentuk kesepakatan untuk melakukan pengawasan ketat terhadap peredaran memes karena diduga merusak kejiwaan pemuda pemudi negara asia.
Kamu diberikan arahan untuk menginvestigasi printer dari seorang warga negara Indonesia yang diduga telah mencetak memes secara illegal, coba cari tahu apa yang sebenarnya dicetak.

[File](https://www.dropbox.com/s/4pcckib0s7cft76/printerlog?dl=0)

author: Bigby

Hint:
