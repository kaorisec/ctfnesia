Description:
Tim analis telah menangkap informasi penting yang tidak dikenali pengirimnya. pcap tersebut diambil dari sebuahperangkat input dalam PC. temukan flags nya!

Hint:
{u'cost': 50, u'id': 6}