Description:
Decode pesan yang menggunakan bahasa indonesia ini. Pesan berawalan dengan gemastik universitas telkom .... 

qudjvbpg wepaunvpbjv bucgtd Gtdwepgjvp dunwyjgje ojc hjeq vjeqjb yuebpeq ijcjd guopiwyje. Gtdwepgjvp ijcjd guopiwyje vuojnp ojnp ijyjb ipcjgwgje vuxjnj cjeqvweq djwywe bpijg cjeqvweq, njojvpj djwywe bpijg, ije bunbwcpv djwywe bpijg bunbwcpv. Gtdwepgjvp njojvpj zpjvjehj dueqqwejgje vjeip. Vjeip zunjvjc ijnp zjojvj vjevugunbj hjeq dudpcpgp jnbp njojvpj jbjw duehudzwehpgje. Yjij qudjvpbpg pep jeij ipdpebj duduxjogje vjeip pep gudwipje ipcjerwbgje webwg ducjgwgje gteugvp gu aye vunaun iueqje vunaunEjdu cpdj udyjb bpbpg vjbw uejd vudzpcje bpbpg vjbw udyjb udyjb bpbpg vjbw bwrwo cpdj, wvunejdu dueqqwejgje jetehdtwv ije bunjgopn dueqqwejgje yjvvstni qudjvbpg. gudwipje vubucjo bungteugvp gu aye vunaun cjgwgjeecjo vvo gu py vjbw bpqj bpbpg iwj iwj vudzpcje bpbpg uejd udyjb bpbpg iucjyje bwrwo iueqje wvunejdu wzwebw. guh jij ip kpcu mpy iueqje yjvvstni vjdj vuyunbp yjvvstni aye vunaun. xjbjbje rjeqje dueqojywv kcjq hjeq jij. Bunpdj gjvpo

Hint:
