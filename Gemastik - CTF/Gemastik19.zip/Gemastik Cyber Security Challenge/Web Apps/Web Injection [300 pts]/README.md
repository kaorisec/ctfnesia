Description:
Soal Hack Vulnerable Web Application dibuat dengan tujuan untuk menguji kemampuan peserta dalam melakukan eksploitasi celah keamanan. Dalam hal ini, celah keamanan yang dapat dieksploitasi adalah SQL Injection. 
Hanya admin yang dapat membuka jalan Anda :-)
http://180.250.135.10:8080/

Hint:
{u'cost': 50, u'id': 5}