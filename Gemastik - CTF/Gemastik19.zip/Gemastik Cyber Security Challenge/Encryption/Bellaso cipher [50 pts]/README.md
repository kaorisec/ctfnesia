Description:
informasi apa yang tersembunyi dalam file ini ? temukan flags dalam file tersebut.

Hint:
