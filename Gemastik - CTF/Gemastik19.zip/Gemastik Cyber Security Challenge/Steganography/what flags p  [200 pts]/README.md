Description:
Salah satu kata dalam bahasa Indonesia dapat membantu perjalanan pulang anda.

jim geovedi akan menuntun anda pulang menuju gambar yang anda inginkan

flag: gemastik{jawaban}
download file di http://180.250.135.11/perjalanan_pulang.wav

Hint:
{u'cost': 10, u'id': 8},{u'cost': 50, u'id': 9}