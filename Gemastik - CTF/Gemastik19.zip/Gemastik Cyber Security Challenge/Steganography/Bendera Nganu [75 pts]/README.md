Description:
temukan flags yang tersembunyi dalam gambar ini

Hint:
