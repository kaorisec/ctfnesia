Description:
lakukan filtering, kemudian decrypt. anda akan menemukan flags dalam direktori ini !

Hint:
{u'cost': 25, u'id': 10}