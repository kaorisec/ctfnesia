Description:
jalankan justrun . temukan flags dalam shellcode tersebut

180.250.135.11:2200

Eksekusi kode yang di-XOR-kan dengan 00 01 .. ff

Hint:
