Description:
temukan flags dalam file binary ini

Hint:
