Description:
Seorang arkeolog sedang meneliti artifak bekas perang saudara Caesar yang terjadi pada tahun 49 SM. Berdasarkan penelitiannya ditemukan sebuah pesan di sekitar artifak terbesut. Bantu arkeolog menemukan apa isi ari pesan tersebut. Pesannya adalah "YNTZIIFZBRTDDDHBUIODLBROZTKFOVH"

Hint:
