Description:
Seorang office boy yg bekerja di JYP Entertainment mengetahui bahwa para member TWICE menggunakan enkripsi tertentu untuk mengirimkan pesan rahasia mereka. Dengan penuh skill yang diajarkan mamank hekel, sang office boy menemukan kode untuk merahasiakan pesan mereka. Bantu sang office boy untuk memecahkan pesan rahasia "Senang-senang v0" dengan mengakses
```
nc min4tozaki.me 31000

Hint:
