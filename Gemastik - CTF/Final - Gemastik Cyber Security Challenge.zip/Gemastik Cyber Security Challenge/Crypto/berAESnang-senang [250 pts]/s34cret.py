from Crypto.Cipher import AES
import sys
import os

key = os.urandom(16)
iv = os.urandom(16)
msg = "-isi pesan member TWICE-"
i = 0

class Unbuffered(object):
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        self.stream.write(data)
        self.stream.flush()

    def writelines(self, datas):
        self.stream.writelines(datas)
        self.stream.flush()

    def __getattr__(self, attr):
        return getattr(self.stream, attr)


sys.stdout = Unbuffered(sys.stdout)


def pad(msg, v):
    if len(msg) % 16 != 0:
        msg = msg + str(v + 5) * ((16 - len(msg) % 16) - 1)
    else:
        msg = pad(msg + str(v + 5), v)
    return msg


def cpadding():
    padding = os.urandom(16)
    return padding


def encryptSenang_senang(iv, key, plain, v):
    cipher = AES.new(key, AES.MODE_***, iv)
    return (cpadding() + iv + cpadding() + cipher.encrypt(plain + str(v)) + cpadding()).encode('hex')


print """
            Selamat datang di Gemastik 12
              Selamat bersenang-senang!
               (https://min4tozaki.me)
                 Jangan aneh-aneh ya
"""
print "Senang-senang v" + str(i), ":"
print encryptSenang_senang(iv, key, pad(msg, i), i)
i += 1
while 1:
    print"""
Menu:

    1. Tebak Senang-senang v0
    2. Senang-senang v""" + str(i) + """
    3. Keluar
    """
    p = raw_input('Pilih : ')
    if p == '1':
        flag_f = raw_input("Input Senang-senang v0 : ")
        try:
            if flag_f == msg:
                print '\nSelamat!!!'
                print 'flag : gemastik12{' + msg +'}'
                exit(1)
            else:
                print 'S4d :('
        except:
            exit(1)
    elif p == '2':
        new_msg = raw_input("Enkrip Senang-senang v"+ str(i) +" : ")
        try:
            print "\nSenang-senang v" + str(i), ":" 
            print encryptSenang_senang(iv, key, pad(new_msg, i), i)
            i += 1
        except:
            exit(1)
    elif p == '3':
        exit(1)
    else:
        exit(1)
