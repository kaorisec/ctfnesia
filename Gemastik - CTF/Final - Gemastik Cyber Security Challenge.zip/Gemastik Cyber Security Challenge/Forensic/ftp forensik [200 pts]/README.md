Description:
Bantu Badrun menemukan flag yang hilang dalam file dokumen miliknya

Hint:
