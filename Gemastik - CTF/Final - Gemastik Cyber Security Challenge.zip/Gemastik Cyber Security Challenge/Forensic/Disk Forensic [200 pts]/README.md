Description:
Seorang penyidik polisi menemukan image dari suatu file system. temukan flags dalam image filesystem ini 

download image di http://10.251.251.194/forensic.img

Hint:
