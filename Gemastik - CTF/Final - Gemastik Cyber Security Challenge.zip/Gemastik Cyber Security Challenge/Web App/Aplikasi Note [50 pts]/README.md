Description:
gali dan temukan kuncinya
http://180.250.135.8:32768/

Hint:
