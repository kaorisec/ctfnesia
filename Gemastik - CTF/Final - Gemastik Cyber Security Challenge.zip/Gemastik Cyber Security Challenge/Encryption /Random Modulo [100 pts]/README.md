Description:
pecahkan modulo ini agar mendapat hasil yang diinginkan 

nc:180.250.135.8:8090

Hint:
