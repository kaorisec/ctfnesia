Description:
dalam direktori ini terdapat flags yang tersembunyi dalam suatu file. temukan flags tersebut.

Hint:
