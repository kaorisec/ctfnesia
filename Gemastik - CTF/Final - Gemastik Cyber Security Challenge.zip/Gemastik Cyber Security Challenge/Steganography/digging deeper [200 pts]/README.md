Description:
melodia menemukan sebuah file aneh, dia kesulitan untuk mencari informasi dalam file tersebut. bantu andi untuk menemukan informasi itu. 

download file : http://180.250.135.20/minatozaki.bmp

Hint:
