Description:
- Analisa Log Serangan SQL Injection

Format Flag : KKSI2019{flag}

Hint:
