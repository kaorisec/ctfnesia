Description:
Terdapat Pesan Rahasia di dalam gambar Bendera Merah Putih

password : benderaNKRI

Hint:
