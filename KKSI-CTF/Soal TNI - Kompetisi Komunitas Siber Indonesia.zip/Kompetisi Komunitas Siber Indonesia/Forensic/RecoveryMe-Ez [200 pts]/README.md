Description:
Recovery me..
flag= KKSI2019{flag_Md5 file flag}

Hint:
