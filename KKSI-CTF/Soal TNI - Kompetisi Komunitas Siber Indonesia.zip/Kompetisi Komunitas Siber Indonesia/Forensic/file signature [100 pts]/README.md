Description:
flag = KKSI2019{flag_md5 file}

Hint:
