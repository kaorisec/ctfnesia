Description:
hash-ez
flag = sha1 file

clue: 
1. tools : hashMyFiles.exe

Hint:
