Description:
Decrypt File di bawah ini

Hint:
