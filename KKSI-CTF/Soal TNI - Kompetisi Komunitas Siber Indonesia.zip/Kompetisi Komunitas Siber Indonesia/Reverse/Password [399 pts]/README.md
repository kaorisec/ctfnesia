Description:
Soal: Analisa "source code" berikut dan dapatkan Flag-nya

Hint:
