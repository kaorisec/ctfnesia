Description:
Dapatkan Kode Rahasia untuk mendapatkan Flag 

Format Flag = KKSI2019{flag}

Hint:
