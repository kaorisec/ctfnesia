Description:
Submit Poin Bonus :

KKSI2019{Semangat_Berjuang_1954}

Hint:
