Description:
http://192.168.3.100:9001/ <br />
Format Flag = KKSI2019{}

Soal: Silahkan login menggunakan user: guest dan password: guest<br />
Untuk mendapatkan <b>Flag</b> anda harus login sebagai <b>administrator</b>

Hint:
