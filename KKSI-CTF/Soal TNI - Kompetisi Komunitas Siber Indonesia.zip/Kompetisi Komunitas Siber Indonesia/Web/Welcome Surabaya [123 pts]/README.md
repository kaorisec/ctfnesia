Description:
http://192.168.3.100:9006/<br />
Format Flag = KKSI2019{}

Soal : Cek "cookie" untuk mendapatkan "Flag-nya" <br />Semangaaat!!

Hint:
