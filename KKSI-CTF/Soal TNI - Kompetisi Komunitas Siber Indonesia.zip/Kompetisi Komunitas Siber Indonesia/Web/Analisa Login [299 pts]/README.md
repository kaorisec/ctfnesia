Description:
http://192.168.3.100:10009/<br />
Format Flag = KKSI2019{}

Soal: Lakukan analisa file "pcap" untuk mendapatkan username dan password, kemudian gunakan login tersebut untuk login ke web dan dapatkan Flag-nya

Hint:
