Description:
http://192.168.3.100:9003/ <br />
Format Flag = KKSI2019{}

Soal: Lakukan <i>BruteForce</i> direktori dan file untuk mendapatkan "clue"

Hint:
