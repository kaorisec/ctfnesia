Description:
Terdapat Pesan Rahasia yang harus di pecahkan 

Password harus di decrypt : 482c811da5d5b4bc6d497ffa98491e38

Format Flag = KKSI2019{flag}

Hint:
