Description:
lost_string =  #6TV#ZDwJPNA30eGQ#X8b7xd#gYrRWHBS9h1Lv!# <br> <b>sha1(md5(flag)) == 64c6d8504872637e8426d4f25fb0436a3f2800dd</b>

Hint:
