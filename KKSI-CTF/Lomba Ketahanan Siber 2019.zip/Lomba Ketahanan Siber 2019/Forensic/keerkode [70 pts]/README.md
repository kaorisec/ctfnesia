Description:
Terdapat Pesan Rahasia di QR

Hint:
