Description:
Gambar peta yang terdapat pesan rahasia, apa pesan nya ? Password harus di decrypt dulu : artnenVAQBARFVN

Hint:
