Description:
nc 172.16.24.21 9000

Hint:
