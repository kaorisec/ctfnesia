Description:
Bongkar File Untuk dapatkan Flag

Hint:
