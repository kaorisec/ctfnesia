Description:
File berikut adalah hasil generate msfvenom. Dapatkah Anda melakukan reverse dan mendapatkan IP/Port tujuan payload reverse shell? Masukkan flag dengan format HUBAD2019{ip:port}

(password: shellcode)

Hint:
