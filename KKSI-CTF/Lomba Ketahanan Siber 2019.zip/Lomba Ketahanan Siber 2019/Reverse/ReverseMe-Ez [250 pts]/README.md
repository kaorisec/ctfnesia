Description:
Revers in aku dong

Hint:
