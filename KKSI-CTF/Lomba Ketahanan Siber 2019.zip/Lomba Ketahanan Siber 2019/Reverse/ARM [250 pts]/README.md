Description:
soal ARM... :D

Hint:
