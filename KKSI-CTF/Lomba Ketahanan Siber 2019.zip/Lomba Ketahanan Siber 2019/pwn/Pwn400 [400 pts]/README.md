Description:
https://drive.google.com/open?id=1kpeNpYVk6xV3NkyGMz78-fKu4LWomkI-    (nc 172.16.24.210 2020)

Hint:
