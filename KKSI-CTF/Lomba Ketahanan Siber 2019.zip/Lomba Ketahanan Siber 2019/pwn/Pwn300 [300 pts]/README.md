Description:
https://drive.google.com/open?id=1_LCxLs_l5YKQPuNnu6vMuBFpGPR6WD1H    (nc 172.16.24.210 2025)

Hint:
