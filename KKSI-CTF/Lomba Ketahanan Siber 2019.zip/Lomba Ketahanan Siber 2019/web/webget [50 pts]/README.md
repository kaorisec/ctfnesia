Description:
Basic Web Hacking 

http://172.16.24.210:2209/

Hint:
