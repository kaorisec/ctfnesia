Description:
Jutaan orang tidak menyadari bahwa website ini ada isinya. Baca kodenya dan retaslah http://172.16.24.210:10001/

"Flag ada di /flag.txt"

Hint:
