# web2 [400 pts]

## Category
Web

## Description
>http://192.168.3.100:1002
>
>
>Max submit its 2.

### Hint
>

## Solution
1.

### Flag
`Flag`
