# web1 [100 pts]

## Category
Web

## Description
>http://192.168.3.100:1001

### Hint
>

## Solution
1.

### Flag
`Flag`
