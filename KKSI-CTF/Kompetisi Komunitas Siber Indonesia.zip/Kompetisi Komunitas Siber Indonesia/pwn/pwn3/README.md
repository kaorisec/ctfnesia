# pwn3 [50 pts]

## Category
pwn

## Description
>nc 192.168.3.100 6464
>
>NgeOver Flow Kuy Kanggg..!

### Hint
>

## Solution
1.

### Flag
`Flag`
