# pwn1 [75 pts]

## Category
pwn

## Description
>nc 192.168.3.100 3001
>

### Hint
>

## Solution
1.

### Flag
`Flag`
