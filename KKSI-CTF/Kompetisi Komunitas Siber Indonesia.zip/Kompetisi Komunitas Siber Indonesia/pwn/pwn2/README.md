# pwn2 [100 pts]

## Category
pwn

## Description
>nc 192.168.3.100 31313

### Hint
>

## Solution
1.

### Flag
`Flag`
