# rev1 [50 pts]

## Category
Reversing

## Description
>Easy bat 
>
><a href="https://drive.google.com/open?id=12wFdXIcj0Lh2ybXIvxuW6qjlqt3MrVg0"> EZ</a>

### Hint
>

## Solution
1.

### Flag
`Flag`
