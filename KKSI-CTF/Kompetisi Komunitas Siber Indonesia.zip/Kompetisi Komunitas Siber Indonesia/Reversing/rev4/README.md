# rev4 [400 pts]

## Category
Reversing

## Description
><a href="https://drive.google.com/open?id=11GJRJWLz1BsIifzDWKhr7DILSiGKWZ-h"> HAHA</a>

### Hint
>

## Solution
1.

### Flag
`Flag`
