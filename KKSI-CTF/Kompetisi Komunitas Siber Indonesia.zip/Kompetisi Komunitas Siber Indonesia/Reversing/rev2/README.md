# rev2 [300 pts]

## Category
Reversing

## Description
>Table revenge 
>
><a href="https://drive.google.com/open?id=1EDVOyyAX822SMTlvNRZt-dw4UB2KZLnb"> Ez </a>

### Hint
>

## Solution
1.

### Flag
`Flag`
