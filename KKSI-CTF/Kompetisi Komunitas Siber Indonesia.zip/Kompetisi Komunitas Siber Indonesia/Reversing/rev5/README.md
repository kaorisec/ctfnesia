# rev5 [75 pts]

## Category
Reversing

## Description
>Pecahkan Kode Pesan yang terpecah belah ya kang 
>
>

### Hint
>

## Solution
1.

### Flag
`Flag`
