# rev3 [100 pts]

## Category
Reversing

## Description
><a href="https://drive.google.com/open?id=1nMA7s8hrg0uVMpRTAIoBeMOHctTqGRPg"> Key </a>

### Hint
>

## Solution
1.

### Flag
`Flag`
