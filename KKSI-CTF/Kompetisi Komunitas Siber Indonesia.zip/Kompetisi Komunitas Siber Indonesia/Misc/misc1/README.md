# misc1 [50 pts]

## Category
Misc

## Description
>nc 192.168.3.100 6699

### Hint
>

## Solution
1.

### Flag
`Flag`
