# misc2 [150 pts]

## Category
Misc

## Description
><a href="https://drive.google.com/open?id=1UOmnz8Kcjqz5ENiJSJ0jfcI7TYrnv2Fo">Flag</a>
>
>sha1(substr(strrev(real_flag), 5, 10)) == b6991c1a4945060a62f727e3086c4f5f608681b1

### Hint
>

## Solution
1.

### Flag
`Flag`
