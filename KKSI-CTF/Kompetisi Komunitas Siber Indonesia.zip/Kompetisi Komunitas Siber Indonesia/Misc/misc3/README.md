# misc3 [200 pts]

## Category
Misc

## Description
><a href="https://drive.google.com/open?id=1aIY0D-xfjb_qT5pstQwYMuLNbM1t8TW1"> Cari </a>
>
>md5(md5(flag)) == 4127539692df051c972b16a459ec9591

### Hint
>

## Solution
1.

### Flag
`Flag`
