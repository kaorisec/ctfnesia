# crypt1 [200 pts]

## Category
Crypto

## Description
><a href="https://drive.google.com/open?id=1awFsbPIW3g0tCr9M7h2zxxoMPov89YmF"> N X R </a>

### Hint
>

## Solution
1.

### Flag
`Flag`
