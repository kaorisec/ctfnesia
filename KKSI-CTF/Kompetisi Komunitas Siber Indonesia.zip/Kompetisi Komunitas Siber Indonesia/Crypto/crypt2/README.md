# crypt2 [400 pts]

## Category
Crypto

## Description
>nc 192.168.3.100 2025 
>
><a href="https://www.youtube.com/watch?v=3ymwOvzhwHs"> Please Steam Twice</a>
>
>
>Limited submit 2 times only

### Hint
>

## Solution
1.

### Flag
`Flag`
