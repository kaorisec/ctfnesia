Description:
Polisi berhasil menemukan sebuah flash drive milik hacker jahat yang kemungkinan berisi file yang bisa menjadi barang bukti kejahatan. Dapatkah kamu membuktikannya?

Hint:
