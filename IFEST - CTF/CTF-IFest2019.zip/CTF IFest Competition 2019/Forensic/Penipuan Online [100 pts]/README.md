Description:
Polisi mendapat laporan bahwa Joko telah tertipu melalui modus penipuan via sms online. nomor hp joko adalah 085711894811. Setelah polisi melakukan tracking, pelaku tertuju di warnet ABC. Berikut kami sertakan file hasil dump komunikasi jaringan warnet tersebut.
Temukan pesan penipuan yang dikirim ke si Joko.

Hint:
