Description:
<code>nc 103.129.221.73 5002</code>

Hint:
