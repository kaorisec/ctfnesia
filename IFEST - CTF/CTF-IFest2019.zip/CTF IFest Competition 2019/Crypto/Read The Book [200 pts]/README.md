Description:
Ditemukan lirik lagu, judul dari lirik lagu tersebut adalah flag.

Hint:
