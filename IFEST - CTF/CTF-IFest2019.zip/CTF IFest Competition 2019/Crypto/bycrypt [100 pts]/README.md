Description:
<code>nc 103.129.221.73 1337</code>

Hint:
