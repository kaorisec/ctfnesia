Description:
base64 is not encryption ?

Author: bot

Hint:
