Description:
Pake terooos kuncinya

Author: bot

Hint:
