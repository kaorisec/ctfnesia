Description:
kang <b>batu akik</b> membuat website sederhana dengan bahasa pemrograman kesukaannya, tapi sepertinya dia membuat kesalahan.

gunakan kesalahan kang <b>batu akik</b> untuk mendapatkan <b>flag.txt</b>

<a>http://103.200.7.150:40612</a>

Author: Toni Setark

Hint:
