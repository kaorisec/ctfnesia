Description:
Saya mempunyai seekor kucing yang kehilangan arah terperangkap didalam sebuah permainan. Apakah kalian bisa membantu kucing saya ini untuk mendapatkan jalan keluarnya.

http://103.200.7.150:40511/ 

Author: mindblow

Hint:
