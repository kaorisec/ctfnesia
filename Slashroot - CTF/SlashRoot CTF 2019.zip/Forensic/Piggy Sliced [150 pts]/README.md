Description:
Panca dikenal sebagai seseorang yang rapi dalam menyimpan file-file yang dimilikinya. Namun suatu hari setelah Panca menghilang, ia hanya meninggalkan sebuah file.
Apakah itu hanyalah corrupted file? 

Author: bemrdo

Hint:
