Description:
Cek channel di Slack untuk mendapatkan free-flagnya!

Hint:
