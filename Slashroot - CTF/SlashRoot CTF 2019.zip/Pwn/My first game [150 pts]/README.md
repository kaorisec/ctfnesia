Description:
Fajar adalah game developer wannabe, kali ini fajar sedang belajar membuat game. <br> Fajar membuat game tersebut dengan berbagai macam fungsi, namun sepertinya fungsi yang dibuat fajar menimbulkan suatu vulnerability.<br>
Dimanakah vulnerability tersebut?
Can you exploit Fajar's game?
`nc 103.200.7.150 50800`
<br>
Author: <b>ChaO</b>

Hint:
