Description:
Jualan buah di acara CTF kayaknya menariq hehehehe

`nc 103.200.7.150 20110`
Author : <b>anti_pencerahan_club</b>

Hint:
