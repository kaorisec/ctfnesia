Description:
Pendinginan
Abis warmup coldup

`nc 103.200.7.150 50400 `

Author : <b>ChaO</b>

Hint:
