Description:
<p>Coba di pwn, warmup doang kok h3h3<p>
`nc 103.200.7.150 50200`

Author : <b>ChaO</b>

Hint:
