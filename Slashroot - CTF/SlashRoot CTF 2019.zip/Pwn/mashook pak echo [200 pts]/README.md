Description:
Haikal baru saja belajar membuat program untuk print setiap string yang di inputkan <br>dengan bahasa C, Namun sepertinya haikal lupa untuk<br> menambahkan sesuatu pada fungsi print nya.  
Can you exploit haikal's program?<p>
`nc 103.200.7.150 50700`
Author : <b>ChaO</b>

Hint:
