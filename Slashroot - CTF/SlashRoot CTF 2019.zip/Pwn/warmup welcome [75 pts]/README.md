Description:
Ahhh warmup, here we go again :(

`nc 103.200.7.150 20114`
Author : <b>anti_pencerahan_club</b>

Hint:
