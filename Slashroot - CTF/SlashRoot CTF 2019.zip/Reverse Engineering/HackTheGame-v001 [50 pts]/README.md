Description:
I'm trying to make a game, please help me to test it :)

author: myitinos

Hint:
