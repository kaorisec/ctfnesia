Description:
Hello guys, there's an update to my last game
Now you can choose your own name! Cool isn't it :)
Also, I made the new Arch-Mage a little weak
please defeat him again!
`nc 103.200.7.150 30311`

author: myitinos

Hint:
