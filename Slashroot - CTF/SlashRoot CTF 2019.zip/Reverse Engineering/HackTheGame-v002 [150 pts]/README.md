Description:
I just updated the game and add new functionality! Please help me test it again! :)

`nc 103.200.7.150 30312`

author: myitinos

Hint:
