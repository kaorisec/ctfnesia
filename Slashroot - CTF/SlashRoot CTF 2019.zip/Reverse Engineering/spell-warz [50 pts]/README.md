Description:
Hello guys, I'm trying to make a game
Will you please try it out for me? :)
While you are at it, can you defeat the Arch-Mage?
`nc 103.200.7.150 30310`

author: myitinos

Hint:
