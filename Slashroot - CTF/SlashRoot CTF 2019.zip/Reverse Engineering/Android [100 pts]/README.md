Description:
Jonny diminta oleh Bono untuk membuat sebuah aplikasi android. Namun di tengah perjalanan, Jonny memilih kabur ke luar negeri dan hanya meninggalkan sebuah link google drive untuk meng-unduh file *.apk nya saja untuk Bono. Saat Bono mencoba aplikasi tersebut, ternyata ada pop-up untuk memasukkan kode serial agar bisa mengakses aplikasi tersebut. Bantulah Bono untuk mendapatkan kode serial dari aplikasi tersebut.

Link: https://drive.google.com/file/d/1XsLxmq9DjuTZn0AU4ol66pHEbJ_I-IFX/view

Author : userpanic

Hint:
