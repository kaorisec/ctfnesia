<?php
class ImageEffect {
    private $file;

    function __construct($file) {
        $this->fileTmp = $file["tmp_name"];
        $this->fileName = "images/" . base64_encode(basename($file["name"]));
        $this->fileRandom = $this->fileRandom();
        $this->generateSephiaEffect();
    }

    function fileRandom(){
        return md5(sha1($this->fileName) . sha1(random_int(1, 9999)));
    }

    function numberOnlyCheck($size){
        return preg_replace('/[^\d\\\]/','',$size);
    }

    function generateSephiaEffect() {
        if (move_uploaded_file($this->fileTmp, $this->fileName)) {
            list($width, $height, $type, $attr) = getimagesize($this->fileName); 
            $w = $this->numberOnlyCheck(isset($_POST['width']) ? $_POST['width'] : $width);
            $h = $this->numberOnlyCheck(isset($_POST['height']) ? $_POST['height'] : $height);
            $cmd = "/usr/bin/convert {$this->fileName} -resize " . stripcslashes($w) . "x" . stripcslashes($h) . " -quality 100 -sepia-tone 90% ./thumbs/images/{$this->fileRandom}";
            system($cmd);
        }
        unlink($this->fileName);
    }

    function __toString() {
        return "<script>location.href='/thumbs/images/{$this->fileRandom}'</script>";
    }
}

$image = $_FILES["file"];
if(isset($image)){
	echo (new ImageEffect($image));
}
