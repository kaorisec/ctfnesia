import ENV
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

def encrypt(filename):
    with open(filename, "r") as f:
        data = pad(f.read(), ENV.SIZE)

    aes = AES.new(ENV.KEY, AES.MODE_OFB, ENV.IV)

    with open(filename + ENV.EXTE, "w") as f:
        f.write(aes.encrypt(data))

    print filename + ENV.EXTE

def decrypt(filename):
    with open(filename, "r") as f:
        data = f.read()

    aes = AES.new(ENV.KEY, AES.MODE_OFB, ENV.IV)
    ext = filename.split(".")
    name = ext[0] + ENV.EXTD + ext[1]

    with open(name, "w") as f:
        f.write(unpad(aes.encrypt(data), ENV.SIZE))

    print name

def main():
    encrypt("file.zip")
    decrypt("file.zip.encrypted")
    encrypt("ENV.py")

if __name__ == '__main__':
    main()