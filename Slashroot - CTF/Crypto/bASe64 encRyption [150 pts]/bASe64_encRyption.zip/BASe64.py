from base64 import b64encode as b64
from Crypto.PublicKey import RSA
from Crypto.Util.number import bytes_to_long, long_to_bytes

FLAG = "SlashRootCTF"

def enc(key, msg, b6="", b4=""):
    key = RSA.importKey(key)
    for i in msg:
        b6 += chr(ord(i) ^ 6)
    msg = pow(int(str(bytes_to_long(b6))[::-1]), key.e, key.n)
    for i in long_to_bytes(msg):
        b4 += chr(ord(i) ^ 4)
    with open("flag.enc", "w") as f:
        f.write(b64(b4))
    return True

def main():
    with open("public.key", "r") as f:
        key = f.read()
    print enc(key, FLAG)

if __name__ == '__main__':
    main()