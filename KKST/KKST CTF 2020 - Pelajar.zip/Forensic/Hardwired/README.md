# Hardwired [100 pts]

**Category:** Forensic
**Solves:** 23

## Description
>

**Hint**
* -

## Solution

### Flag

