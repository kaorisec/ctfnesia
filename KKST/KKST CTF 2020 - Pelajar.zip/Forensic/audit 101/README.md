# audit 101 [244 pts]

**Category:** Forensic
**Solves:** 17

## Description
>

**Hint**
* -

## Solution

### Flag

