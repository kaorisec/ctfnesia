# InspectUs [275 pts]

**Category:** Forensic
**Solves:** 16

## Description
>

**Hint**
* -

## Solution

### Flag

