from Crypto.Util.Padding import pad, unpad
from Crypto.Cipher import AES
BLOCK_SIZE = 32

key = '6b?dadcd478f76?0' # i think i lost my key :(
cipher = AES.new(key.encode('utf8'), AES.MODE_ECB)
msg = cipher.encrypt(pad(b'hello_world', BLOCK_SIZE))
print(msg.encode('hex'))
