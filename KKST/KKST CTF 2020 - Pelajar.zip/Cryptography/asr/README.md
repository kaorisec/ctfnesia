# asr [500 pts]

**Category:** Cryptography
**Solves:** 1

## Description
>nc 207.148.78.100 40001

**Hint**
* -

## Solution

### Flag

