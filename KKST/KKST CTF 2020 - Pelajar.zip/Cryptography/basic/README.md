# basic [331 pts]

**Category:** Cryptography
**Solves:** 14

## Description
>**PPXY2020{-- .. ... ... ..--.- - .... . ..--.- --- .-.. -.. ..--.- ... -.-. .... --- --- .-.. ..--.- -.-. - ..-. ..--.. }**

**Hint**
* -

## Solution

### Flag

