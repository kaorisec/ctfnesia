# Apakah perlu patching [379 pts]

**Category:** Reversing & PWN
**Solves:** 12

## Description
>

**Hint**
* -

## Solution

### Flag

