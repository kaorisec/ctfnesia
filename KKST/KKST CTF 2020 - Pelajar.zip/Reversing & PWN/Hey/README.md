# Hey [500 pts]

**Category:** Reversing & PWN
**Solves:** 0

## Description
>Aku hanya mengingat bagian depan dari passwordku yaitu JUST dan seingetku panjang keynya dibawah 10\r\n\r\n\r\n**SE EE RK TK SS VV VR RR VK SE EE TE VR ER VV SE ST KR SS ER TT ES RS KS RS RV EK TK TV VK**

**Hint**
* -

## Solution

### Flag

