import random

import flag

if __name__ == '__main__':
    inp = input('guess an integer. your guess: ')
    if inp.isdigit() and int(inp) == random.randint(10**3, 10**5):
        flag.decrypt_flag()

