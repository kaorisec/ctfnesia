# Basic [491 pts]

**Category:** Reversing & PWN
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

