# HLA basic [419 pts]

**Category:** We
**Solves:** 10

## Description
>HLA http://207.148.78.100:20001

**Hint**
* -

## Solution

### Flag

