# Easy Pakai Banget [496 pts]

**Category:** We
**Solves:** 3

## Description
>http://207.148.78.100:20004

**Hint**
* -

## Solution

### Flag

