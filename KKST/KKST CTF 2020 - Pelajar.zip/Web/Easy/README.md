# Easy [475 pts]

**Category:** We
**Solves:** 6

## Description
>http://207.148.78.100:20003

**Hint**
* -

## Solution

### Flag

