# Bongkar [500 pts]

**Category:** Forensic
**Solves:** 18

## Description
>Mungkin dengan mem-"bongkarnya" kalian akan menemukan sesuatu

**Hint**
* -

## Solution

### Flag

