# Cinderella [750 pts]

**Category:** Forensic
**Solves:** 16

## Description
>Cinderella menyembunyikan sesuatu didalam foto dirinya.\r\nTolong bantu keluarkan apa yang sedang disembunyikan oleh Cinderella.

**Hint**
* -

## Solution

### Flag

