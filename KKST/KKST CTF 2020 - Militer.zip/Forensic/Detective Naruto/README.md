# Detective Naruto [750 pts]

**Category:** Forensic
**Solves:** 18

## Description
>Bantu naruto untuk berperang.

**Hint**
* -

## Solution

### Flag

