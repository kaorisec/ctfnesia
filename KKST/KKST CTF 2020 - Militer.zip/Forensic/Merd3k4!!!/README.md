# Merd3k4!!! [750 pts]

**Category:** Forensic
**Solves:** 18

## Description
>DIberikan sebuah file PCAP yang dicurigai adalah hasil bruteforce. Apakah kalian bisa menemukan informasi sensitif pada file ini ?

**Hint**
* -

## Solution

### Flag

