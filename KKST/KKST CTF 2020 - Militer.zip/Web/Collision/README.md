# Collision [750 pts]

**Category:** We
**Solves:** 15

## Description
>A: Tell me more about MD5!\r\nB: It is MAGIC!\r\nA: What about PHP?\r\nB: PHP loves juggling\r\n\r\n[http://149.28.154.48:20003](http://149.28.154.48:20003)

**Hint**
* -

## Solution

### Flag

