# Unauthorized [750 pts]

**Category:** We
**Solves:** 16

## Description
>[http://149.28.154.48:20004/](http://149.28.154.48:20004/)

**Hint**
* -

## Solution

### Flag

