# Secure Area System [500 pts]

**Category:** We
**Solves:** 12

## Description
>[http://149.28.154.48:20002](http://149.28.154.48:20002)

**Hint**
* -

## Solution

### Flag

