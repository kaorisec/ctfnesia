# Lokal AD [1000 pts]

**Category:** We
**Solves:** 13

## Description
>[http://149.28.154.48:20005](http://149.28.154.48:20005)

**Hint**
* -

## Solution

### Flag

