# Break The Password [1000 pts]

**Category:** Reverse & PWN
**Solves:** 13

## Description
>Seseorang programmer telah membuat sebuah file yang mana file itu berisi informasi yang penting dan telah diberi kata sandi agar tidak sembarang orang dapat melihat informasi tersebut.  Suatu hari programmer itu mengalami kecelakaan dan meninggal dunia. Selanjutnya file itu di berikan kepada asistennya, akan tetapi asisten itu tidak mendapatkan informasi tentang kata sandi untuk membuka file. Sang programmer pernah cerita kepada asistennya bahwa sewaktu membuat kata sandi, file mengandung sebuah fungsi salah satu operasi Boolean. Asisten tersebut berasumsi bahwa file tersebut dapat dilakukan Reverse engineering untuk menemukan kata sandi yang tepat.

**Hint**
* -

## Solution

### Flag

