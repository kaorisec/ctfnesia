# Sayonara and Say Thanks to My Buffy [500 pts]

**Category:** Reverse & PWN
**Solves:** 12

## Description
>Notes From Programmer:\r\n\r\nSir, I want to say thanks for all of this hapiness and I want to say goodbye for my buffalo.\r\n\r\nHere is I sent the last program that I can made. Thank you.

**Hint**
* -

## Solution

### Flag

