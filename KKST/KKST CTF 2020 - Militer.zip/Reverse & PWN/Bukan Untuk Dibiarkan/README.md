# Bukan Untuk Dibiarkan [750 pts]

**Category:** Reverse & PWN
**Solves:** 15

## Description
>Gali kemampuan dan temukan !

**Hint**
* -

## Solution

### Flag

