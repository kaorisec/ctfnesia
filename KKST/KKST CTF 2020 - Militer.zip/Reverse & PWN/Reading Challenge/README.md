# Reading Challenge [750 pts]

**Category:** Reverse & PWN
**Solves:** 14

## Description
>Reading gives us someplace to when we have stay where we are

**Hint**
* -

## Solution

### Flag

