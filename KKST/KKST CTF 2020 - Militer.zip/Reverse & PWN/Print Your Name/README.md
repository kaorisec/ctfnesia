# Print Your Name [1000 pts]

**Category:** Reverse & PWN
**Solves:** 11

## Description
>Sepertinya kalian dapat masuk ke sistem melalui ini, it just buffer overflow with another topping on it\r\n\r\n\r\n`ncat 149.28.154.48 30001` atau `nc 149.28.154.48 30001`

**Hint**
* -

## Solution

### Flag

