# Inarkunai [750 pts]

**Category:** OSINT
**Solves:** 13

## Description
>Perusahaan PT. Inarkunai sedang meluncurkan aplikasi open source untuk membantu komunitas IT di Indonesia. Namun, dari pihak perusahaan menginginkan Security Consultant untuk membantu perusahaan mengamankan dan memastikan informasi di publik apakah sudah aman atau belum untuk mulai menjalankan aktivitas mereka.\r\n\r\nKonsultan dapat menghubungi admin perusahaan menggunakan data kontak perusahaan yang sudah terlampir dari email, social media, maupun media berbagi Medium.

**Hint**
* b"Dont forget to check new Posts and new Events at our social Media  :)\r\n\r\nSocial Media with no security awareness is a disaster. So keep in touch with us at Social media. Email is not really interesting :)"

## Solution

### Flag

