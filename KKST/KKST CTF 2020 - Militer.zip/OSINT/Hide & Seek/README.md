# Hide & Seek [1000 pts]

**Category:** OSINT
**Solves:** 12

## Description
>Setelah mendapatkan data milik Developer pada challenge "Find My Number", ternyata Developer ini menyimpan satu rahasia pada salah satu platform paste online yang cukup terkenal. \r\nDapatkah kalian mencari tahu apa yang merupakan rahasia tersimpan dari Developer tersebut ?

**Hint**
* Flag yang sebenarnya bukan di https://pastebin.com/3qeJa7XV

## Solution

### Flag

