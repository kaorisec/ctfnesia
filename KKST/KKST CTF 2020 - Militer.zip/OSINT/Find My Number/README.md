# Find My Number [750 pts]

**Category:** OSINT
**Solves:** 13

## Description
>Developer pada website https://2020.kks-tniad.id/ sangat suka bermain game bernama Dota 2. Dia memainkannya hampir setiap malam bersama dengan teman-temannya. \r\n\r\nNamun pada suatu hari, ternyata dia mendapatkan tagihan pulsa yang sangat besar dikarenakan adanya seseorang yang tidak bertanggung jawab mengirimkan kode OTP secara massal pada nomor ponselnya.\r\n\r\nBisakah kalian mencari nomor developer tersebut ?\r\n\r\nFormat Flag: KKST2020{NomorTelepon}

**Hint**
* -

## Solution

### Flag

