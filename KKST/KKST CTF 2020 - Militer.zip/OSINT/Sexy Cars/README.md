# Sexy Cars [750 pts]

**Category:** OSINT
**Solves:** 14

## Description
>Bisakah kalian mencari siapa nama orang yang pertama kali memposting gambar ini ke internet\r\n\r\nflag adalah KKST2020{username_orangnya}

**Hint**
* -

## Solution

### Flag

