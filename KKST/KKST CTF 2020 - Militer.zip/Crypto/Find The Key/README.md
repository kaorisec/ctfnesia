# Find The Key [500 pts]

**Category:** Crypto
**Solves:** 17

## Description
>Saya sudah menemukan kunci untuk mebuka sebuah file, tapi saya bingung cara menggunakannya.

**Hint**
* -

## Solution

### Flag

