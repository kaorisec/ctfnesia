# Back to Basic [500 pts]

**Category:** Crypto
**Solves:** 17

## Description
>

**Hint**
* -

## Solution

### Flag

