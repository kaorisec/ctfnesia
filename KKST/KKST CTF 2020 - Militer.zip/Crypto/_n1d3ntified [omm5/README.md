# _n1d3ntified [omm5 [1000 pts]

**Category:** Crypto
**Solves:** 10

## Description
>Pada 10 tahun yang lalu di sebuah negara, dilakukan sebuah penyelidikan tentang organisasi rahasia yang melakukan aktivitas mencurigakan di negara tersebut. Kemudian dilakukan proses penyadapan komunikasi pengiriman pesan yang dilakukan oleh organisasi yang menyebut diri mereka Aliens. Dari hasil penyadapan tersebut, lembaga intel dan pemerintah berhasil menyusun beberapa data berupa kode dan huruf yang disimpan pada laporan intercept pada file txt yang dikirimkan.\r\n\r\nAnda diharapkan dapat membantu pemerintah negara tersebut untuk memecahkan kode dari organisasi Aliens yang dicurigai melakukan aktivitas ilegal dan kriminal. Didapatkan sebuah attachment gambar dan file kode hasil komunikasi dari aktivitas yang dilakukan malam kemarin.\r\n\r\nP.S. :\r\nHati - hati terhadap jebakan alien

**Hint**
* 1337 Mix People\n* Pada setiap huruf di awal kalimat alay, dapat digunakan menjadai link baru menuju ke informasi selanjutnya.\n* Lihatlah ke atas pada bendera itu saudaraku\n* Warning, case is a matter things

## Solution

### Flag

