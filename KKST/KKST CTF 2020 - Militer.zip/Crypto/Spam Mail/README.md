# Spam Mail [500 pts]

**Category:** Crypto
**Solves:** 12

## Description
>Murid-murid SMA yang berada di ruangan **16-JSF** sedang melakukan kegiatan pelatihan komputer di Sekolahnya dan mendapat tugas dari guru pembimbing untuk dikerjakan. Tugas tersebut dikirimkan oleh gurunya melalui email. Tiba-tiba ada seorang siswi kaget setelah melihat isi dalam emailnya. Ketika siswi tersebut membuka Email, terdapat banyak **SPAM EMAIL** dari orang yang tidak dikenal.\r\nDia merasa waspada karena banyak email yang masuk dengan isi yang sama secara berulang. Dia bertanya kepada gurunya untuk mengecek email tersebut. Setelah sang guru melihat isi email, guru tersebut melakukan analisis data. Data tersebut terdiri dari isi email dan ada sebuah gambar berupa kode **SEMAPHORE** (lowercase).\r\nKemudian Guru tersebut meminta bantuan anda untuk memecahkan maksud dari orang tidak dikenal tersebut.

**Hint**
* -

## Solution

### Flag

