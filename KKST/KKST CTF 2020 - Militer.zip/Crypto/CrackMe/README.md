# CrackMe [1000 pts]

**Category:** Crypto
**Solves:** 13

## Description
>Sepertinya Bob kehilangan kunci yang diberikan oleh Alice. Dapatkah kalian membantu Bob untuk mendapatkan kuncinya kembali dan membuat Bob berhasil membaca pesan rahasia yang dikirimkan oleh Alice ?

**Hint**
* -

## Solution

### Flag

