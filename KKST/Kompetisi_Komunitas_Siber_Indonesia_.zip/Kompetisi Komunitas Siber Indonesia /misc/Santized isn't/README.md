# Santized isn't? [400 pts]

## Category
Misc

## Description
>nc 192.168.3.100 30004

### Hint
>

## Solution


### Flag

