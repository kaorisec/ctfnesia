# makanan [300 pts]

## Category
Reverse

## Description
>Hay kang lama tak jumpa

Reverse this file and get Flag 

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

