# cilok [100 pts]

## Category
Reverse

## Description
>Hay kang how are you ?

Reverse this file and get Flag 

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

