# repers [150 pts]

## Category
Reverse

## Description
>Hay kang ketemu di KKSI 2019

Reverse this file and get Flag 

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

