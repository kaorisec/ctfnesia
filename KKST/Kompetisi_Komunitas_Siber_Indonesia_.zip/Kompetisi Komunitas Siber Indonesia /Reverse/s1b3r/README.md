# s1b3r [250 pts]

## Category
Reverse

## Description
>Hay kang piye kabare ?

Reverse this file and get Flag 

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

