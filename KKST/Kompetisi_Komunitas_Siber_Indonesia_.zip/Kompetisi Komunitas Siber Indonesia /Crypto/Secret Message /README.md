# Secret Message [400 pts]

## Category
Crypto

## Description
>http://192.168.3.100:30001


Pada waktu perang baru baru ini, Komandan HKL ingin dibuatkan cara berkomunikasi yang aman. Maka ajudannya mengajukan beberapa cara enkripsi. Ajudannya bilang serperti berikut ini algoritmanya. Jadi nanti ada input text pak, Lalu kita generate 1 key sesuai panjang dari inputanya. Lalu kita lakukan caesar ciper dari inputan dengan key pertama tadi. Setelah itu kita simpan hasilnya pada operation1. Lalu kita generate lagi key2 sesuai dengan panjang operation 1. Lalu operation 1 dilakukan caesar shift lagi dengan key2 lalu disimpan pada operasi 2. Setelah itu kita buat key 3 dari xor key1 dan key2. Lalu terakhir kita xor lagi operation2 dan key3



input <b>flag</b> untuk pesan rahasia.

### Hint
>

## Solution


### Flag

