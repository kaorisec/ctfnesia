# KripKripKripTOO! [200 pts]

## Category
Crypto

## Description
>Hay kang semangat ya !!!  

nc 192.168.3.100 6978  

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

