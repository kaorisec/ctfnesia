# More bug More fun [400 pts]

## Category
Web

## Description
>http://192.168.3.100:30002

### Hint
>

## Solution


### Flag

