# Sauce? [400 pts]

## Category
Web

## Description
>http://192.168.3.100:30003


*Note

Tidak perlu menggunakan SQLmap dan automasi lainya.

### Hint
>

## Solution


### Flag

