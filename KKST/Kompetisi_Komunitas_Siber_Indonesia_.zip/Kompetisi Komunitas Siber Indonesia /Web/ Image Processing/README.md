# Image Processing [450 pts]

## Category
Web

## Description
>Retaslah 
http://192.168.3.100:10000.


https://drive.google.com/file/d/1WRkwUqHGOC3iOgL_hcLy-intXiwoc3Id/view?usp=sharing

### Hint
>perhatikan </br>
from PIL import image </br>
import magic

## Solution


### Flag

