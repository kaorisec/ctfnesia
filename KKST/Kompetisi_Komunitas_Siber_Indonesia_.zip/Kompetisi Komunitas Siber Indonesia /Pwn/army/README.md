# army [300 pts]

## Category
Pwn

## Description
>get license kang

nc 192.168.3.101 3123

### Hint
>

## Solution


### Flag

