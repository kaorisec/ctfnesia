# barang [250 pts]

## Category
Pwn

## Description
>Hay kang udah siap ?

nc 192.168.3.100 1169

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

