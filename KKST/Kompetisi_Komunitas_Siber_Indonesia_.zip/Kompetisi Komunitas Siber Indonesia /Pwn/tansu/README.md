# tansu [150 pts]

## Category
Pwn

## Description
>Hay kang piye kabare ?

nc 192.168.3.100 1168

Format Flag : KKSI2019{flag}

### Hint
>

## Solution


### Flag

