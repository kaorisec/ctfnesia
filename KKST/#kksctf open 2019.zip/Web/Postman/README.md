# Postman [100 pts]

**Category:** Web
**Solves:** 149

## Description
>Hey, some kaсkers steal my mail. Can you help return and deliver it?

tasks.open.kksctf.ru:8001

@greg0r0

**Hint**
* 

## Solution

### Flag

