# Predictor [997 pts]

**Category:** Web
**Solves:** 4

## Description
>We found a login form to the kackers secret site. It seems to be using some kind of OTP, and we intercepted some strange file. I think evil kackers are keeping something important there, try to get it out!

http://tasks.open.kksctf.ru:20007/

@rubikoid

**Hint**
* 

## Solution

### Flag

