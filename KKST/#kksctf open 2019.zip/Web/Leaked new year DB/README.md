# Leaked new year DB [1000 pts]

**Category:** Web
**Solves:** 2

## Description
>kackers stole a gift recipient database and try to sell it on the Internet!
seems their application is not so secure.
They also have some secrets, get it!

http://tasks.open.kksctf.ru:20006/

Author: @thunderstorm8

**Hint**
* 

## Solution

### Flag

