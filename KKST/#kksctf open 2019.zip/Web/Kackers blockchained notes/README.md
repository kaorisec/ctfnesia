# Kackers blockchained notes [919 pts]

**Category:** Web
**Solves:** 16

## Description
>We found a strange service with secrets that use blockchain-like technology. Evil kackers use it to store their secrets, maybe u can find something interesting.

http://tasks.open.kksctf.ru:20005/

@thunderstorm8

**Hint**
* Next secret is chained to previous, link to next secret contains current location and current secret (except first step)

## Solution

### Flag

