# Stego Warmup [100 pts]

**Category:** Misc
**Solves:** 286

## Description
>We get some file. Can you find secret?

@greg0r0

**Hint**
* 

## Solution

### Flag

