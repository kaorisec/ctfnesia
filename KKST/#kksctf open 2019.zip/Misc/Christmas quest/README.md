# Christmas quest [983 pts]

**Category:** Misc
**Solves:** 8

## Description
>Hey there!

So right before New Year's, we decided to go through all of the old stuff at the faculty office. Guess what we found among all the boxes! There were a whole bunch of floppy disks right from the 90s and such. Really looked like dinosaurs used those. Because there are no disk trays on the Macbooks that we use, we had to get a super old PC running (barely managed to boot the damn thing).

One of the floppies was quite interesting. It had a console-based game on it, similar to ones that were popular in the 80s. I tried it and got stuck on the first enemy! Maybe you'll manage to get further? We ended up putting the game on our server, be sure to check it out here:

`nc tasks.open.kksctf.ru 8005`

P. S. There's an intriguing file I found in the game's folder. Looks like something out of the source files. Maybe it can help somehow?

P.P.S Use Cool Retro Term for better experience

https://drive.google.com/open?id=1jwH63jg_aSV9Hzr6y30c2TfP_ozUxGta

**Hint**
* 

## Solution

### Flag

