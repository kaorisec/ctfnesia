# Xmas Tree [100 pts]

**Category:** Misc
**Solves:** 214

## Description
>Do you like to decorate the Christmas tree?

**Hint**
* 

## Solution

### Flag

