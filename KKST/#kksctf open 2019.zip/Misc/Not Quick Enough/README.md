# Not Quick Enough [971 pts]

**Category:** Misc
**Solves:** 10

## Description
>To: Me my_mail123@mirea.ru  
From: Chandler thegreatchad@example.com  
Subject: work stuff  

Hey buddy,

How's it going? I was wondering if you could help our team out with a test case of sorts. We wrote a prototype service which is meant for sorting arrays but we haven't had enough time to test it through.

Do you mind helping out with some testing? Just going through the motions and seeing that everything runs OK without crashing on the user's side would be fine. Feel free to tell me if you're too busy and won't have time for it, too.

You can find it here:
`nc tasks.open.kksctf.ru 8009`

Thank you in advance!

https://drive.google.com/open?id=1wmUifOkBGOlFFrVuODoXFzF84oWcSDn2

**Hint**
* 

## Solution

### Flag

