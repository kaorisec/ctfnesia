# Xmas Tree 2 [100 pts]

**Category:** Reverse
**Solves:** 52

## Description
>Looks like another kackers's intrusion artifact. Find password for this program and it'll tell you its secrets.

**Hint**
* 

## Solution

### Flag

