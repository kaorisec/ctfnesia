# Buffalo Reverse [100 pts]

**Category:** Reverse
**Solves:** 75

## Description
>Buffalo dead while reversing this task.

Warning:
Flag format is changed (not kks)! But it still using brackets.

@greg0r0

**Hint**
* 

## Solution

### Flag

