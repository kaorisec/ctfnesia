# Secret IMAGination [995 pts]

**Category:** Reverse
**Solves:** 5

## Description
>Here's a minimal system image. Evil kackers know a way to IMAGine secrets, so your task is to bring them to the real world.

You may need to surround flag with kks{}

https://drive.google.com/open?id=1GeXYdPdKDx2xeWaqd9_FxitWxkwpLlGY

@servidei9707

**Hint**
* 

## Solution

### Flag

