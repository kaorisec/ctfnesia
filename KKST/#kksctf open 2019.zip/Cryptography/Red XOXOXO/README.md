# Red XOXOXO [100 pts]

**Category:** Cryptography
**Solves:** 93

## Description
>And another message captured: `-*;91~.,1*1=12~;-*?<27-6;:r~+-;~=27;0*~*1~=100;=*p~7y3~)?7*709~81,~+,~,;.2'p~55-%?**j=5.?*.:j)0#`

@anfinogenov

**Hint**
* 

## Solution

### Flag

