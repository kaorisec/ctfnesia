# Every day i'm shuffling [481 pts]

**Category:** Cryptography
**Solves:** 39

## Description
>![Imgur](https://i.imgur.com/W7nTKED.jpg)

@anfinogenov

https://drive.google.com/open?id=16excnDOhaQUaSVlwrzT8Sk69eboB7p-K  
https://drive.google.com/open?id=1tQfED8-ULWK2mcjodmiUPlMOK161p2Mv

**Hint**
* 

## Solution

### Flag

