# Message from base [365 pts]

**Category:** Cryptography
**Solves:** 43

## Description
>We captured some weird messages from _kackers group_ bots. We are not 100% sure this is encrypted, but we still can't read or decode the message. Help us!

`2bi4j2fcjli84edk07kbjj3cggg3k5ih0hcgg710260lak1ibead1gf15hflb5f41`

@anfinogenov

**Hint**
* 

## Solution

### Flag

