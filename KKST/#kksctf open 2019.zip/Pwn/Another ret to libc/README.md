# Another ret to libc [997 pts]

**Category:** Pwn
**Solves:** 4

## Description
>Kackers are hiding some crucial information here. We don't know what exactly it is, but can you help us to retrive it? 

`nc tasks.open.kksctf.ru 10001`

libc: https://drive.google.com/open?id=1t9G-yAWk0c8eLTlDZ45DstV0UqmrScgS

**Hint**
* 

## Solution

### Flag

