# Heap-Heap-Hooray! [988 pts]

**Category:** Pwn
**Solves:** 7

## Description
><img src="https://i.imgur.com/9oagyn3.png" width="100%">

P.S. glibc2.27 is the greatest version of glibc!

`nc tasks.open.kksctf.ru 10000`

lib: https://drive.google.com/open?id=1cpyWT_cRu2szV2u4lpp5ESgMMXUP3IMu  
heap: https://drive.google.com/open?id=1Cnx-VBufgdowFXvE7iIPc6mBZRbnZc7W  
df: https://drive.google.com/open?id=1TRfyx8-5DZrQ70ah8eKLTCbxFT4vBAWj

**Hint**
* 

## Solution

### Flag

