# Baby buffer overflow [100 pts]

**Category:** Pwn
**Solves:** 86

## Description
>We received new message from kackers. They laugh at us being sure that no one will ever be able to break them and even left a description of what needs to be done. Show them what happens to overly confident people!

`nc tasks.open.kksctf.ru 10002`

https://drive.google.com/open?id=1xSswzDDa0lhtGZ2zfhkRr_kNHD0pcdIy

@oldwayfarer

**Hint**
* 

## Solution

### Flag

