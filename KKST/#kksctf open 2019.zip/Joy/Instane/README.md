# Instane [267 pts]

**Category:** Joy
**Solves:** 19

## Description
>#kksctf threat intel team searching for kackers and posting it's progress to some social network. Maybe, their evidences will help you

**Hint**
* 

## Solution

### Flag

