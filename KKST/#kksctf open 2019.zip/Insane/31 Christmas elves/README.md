# 31 Christmas elves [1000 pts]

**Category:** Insane
**Solves:** 1

## Description
>33 Christmas elves from _kackers group_ have played nasty trick with this executable and stored their secret in it. We know that these elves like stego and addition modulo 2, and don't like brute force. Can you get the flag?

https://drive.google.com/open?id=1OKnC5T1mDd3aYlFdxPdheGOyIemosFkP

@servidei9707

**Hint**
* "31 c0" or "33 c0", what's your choice?

## Solution

### Flag

