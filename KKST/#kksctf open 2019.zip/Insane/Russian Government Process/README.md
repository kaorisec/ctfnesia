# Russian Government Process [988 pts]

**Category:** Insane
**Solves:** 7

## Description
>To counteract kackers, you decided to create an organization for the implementation of paper security mechanisms. Unfortunately (or fortunately) you decided to create this organization in Russia. 

Read all the necessary documents and go through this paper Russian Government Process.

To complete this task, we have sent you a package of necessary documents. It includes a worker's memo, a short life story, a lunch menu, and an accounting form.

You will find some parts of the necessary information in these papers.

Be sure to look to create an atmosphere - > https://www.youtube.com/watch?v=B6bN_T92SYY


P.S. The Finance.pdf file has moved a little, but it does not interfere with the solution

@greg0r0

**Hint**
* 

## Solution

### Flag

