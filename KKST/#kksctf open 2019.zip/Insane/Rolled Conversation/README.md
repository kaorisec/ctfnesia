# Rolled Conversation [997 pts]

**Category:** Insane
**Solves:** 4

## Description
>We have intercepted some strange dialog between two infected hosts. Please, help us decode this and get kackers plans

https://drive.google.com/open?id=158byn_W3izzQLBqPlo3IAa4zUy0bGp15

@anfinogenov

**Hint**
* These guys using almost the same files to transfer messages. What's the difference? Can we visualize this diff?

## Solution

### Flag

