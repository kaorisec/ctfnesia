# A_MAZE_ING [983 pts]

**Category:** PPC
**Solves:** 8

## Description
>Do you like rougelike games? Our monsters are decorating a Christmas tree so you can pass without a problem. Except one: you must hurry! Any unnecessary turn can be a reason for being late for holiday!

`nc tasks.open.kksctf.ru 31397`

@servidei9707

P.S. `urld` to move. You can send sequence of turns at one time, ex. `rrddll`

**Hint**
* 

## Solution

### Flag

