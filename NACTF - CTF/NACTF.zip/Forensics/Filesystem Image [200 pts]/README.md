Description:
Put the path to flag.txt together to get the flag! for example, if it was located at `ab/cd/ef/gh/ij/flag.txt`, your flag would be `nactf{abcdefghij}`

- ewn10

Hint:
