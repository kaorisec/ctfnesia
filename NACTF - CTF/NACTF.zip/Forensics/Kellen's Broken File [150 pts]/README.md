Description:
Kellen gave in to the temptation and started playing World of Tanks again. He turned the graphics up so high that something broke on his computer!

Kellen is going to lose his HEAD if he can't open this file. Please help him fix this broken file.

Hint:
