Description:
The20thDuck sent me this really annoying audio file. It's way too high pitched to be his voice. What he is trying to tell me? Maybe its a code; he is the crypto master after all. 

You may have to convert file types.

You will need to insert the string into the nactf{...} form before submitting.

Hint:
