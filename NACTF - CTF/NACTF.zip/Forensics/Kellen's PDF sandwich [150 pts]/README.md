Description:
Kellen was playing some more World of Tanks.... 

He played so much WOT that he worked up an appetite.

 Kellen ripped a PDF in half. He then treated these two halves as bread and placed a different PDF on the inside (yummy PDF meat!). That sounds like one good PDF sandwich. PDF on the outside and inside! YUM!

Hint:
