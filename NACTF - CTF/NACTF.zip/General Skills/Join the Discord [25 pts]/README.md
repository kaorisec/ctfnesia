Description:
Go to the NACTF home page and find the link to the Discord server. A flag will be waiting for you once you join. So will Austin.

Hint:
