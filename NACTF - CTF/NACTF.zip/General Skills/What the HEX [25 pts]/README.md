Description:
What the HEX man! My friend Elon just posted this message and I have no idea what it means >:( Please help me decode it:

https://twitter.com/kevinmitnick/status/1028080089592815618?lang=en

Leave the text format: no need to add nactf{} or change punctuation/capitalization

Hint:
