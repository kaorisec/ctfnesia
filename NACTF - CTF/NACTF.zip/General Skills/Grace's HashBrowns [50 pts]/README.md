Description:
Grace was trying to make some food for her family but she really messed it up. She was trying to make some hashbrowns but instead, she made this: 

f5525fc4fc5fdd42a7cf4f65dc27571c

I guess Grace is a really bad cook. But at least she tried to add some md5 sauce.

remember to put the flag in nactf{....}

Hint:
