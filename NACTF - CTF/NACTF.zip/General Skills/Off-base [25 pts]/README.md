Description:
It seems my friend Rohan won't stop sending cryptic messages and he keeps mumbling something about base 64. Quick! We need to figure out what he is trying to say before he loses his mind...


bmFjdGZ7YV9jaDRuZzNfMGZfYmE1ZX0=

Hint:
