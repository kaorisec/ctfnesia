Description:
John's written a handy calculator app - in bash! Too bad it's not that secure...

Connect at `nc shell.2019.nactf.com 31214`

Hint:
