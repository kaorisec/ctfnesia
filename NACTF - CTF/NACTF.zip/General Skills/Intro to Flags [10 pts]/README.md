Description:
Your flag is `nactf{w3lc0m3_t0_th3_m4tr1x}`.

Hint:
