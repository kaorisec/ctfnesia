Description:
Open up a terminal and connect to the server at shell.2019.nactf.com on port 31242 and get the flag!

Use this netcat command in terminal:

`nc shell.2019.nactf.com 31242`

Hint:
