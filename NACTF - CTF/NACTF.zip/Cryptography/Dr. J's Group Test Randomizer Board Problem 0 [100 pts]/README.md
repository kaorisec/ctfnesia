Description:
Dr. J created a fast pseudorandom number generator (prng) to randomly assign pairs for the upcoming group test. Leaf really wants to know the pairs ahead of time... can you help him and predict the next output of Dr. J's prng? Leaf is pretty sure that Dr. J is using the middle-square method.

`nc shell.2019.nactf.com 31425`

The server is running the code in class-randomizer-0.c. Look at the function nextRand() to see how numbers are being generated!

- The20thDuck

Hint:
