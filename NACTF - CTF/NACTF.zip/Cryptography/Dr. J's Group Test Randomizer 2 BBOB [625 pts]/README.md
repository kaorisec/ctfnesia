Description:
This is it. The last group test of the year. Dr. J patched his prng again so numbers won't repeat, so I guess Leaf won't get to know the group test pairs ahead of time... oh WEYL. Who knew middle square could make such a good prng?

`nc shell.2019.nactf.com 31382`

- The20thDuck

Hint:
