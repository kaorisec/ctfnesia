Description:
Ruthie is very inhumane. She keeps her precious pigs locked up in a pen. I heard that this secret message is the password to unlocking the gate to her PIGPEN. Unfortunately, Ruthie does not want people unlocking the gate so she encoded the password. Please help decrypt this code so that we can free the pigs!

P.S. 
"_"  ,  "{"  , and "}" are not part of the cipher and should not be changed

P.P.S
the flag is all lowercase

Hint:
