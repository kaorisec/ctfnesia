Description:
Dr. J is back with another group test, and he patched his prng so we can't predict the next number based on the previous one! Can still you help Leaf predict the next output of the prng?

`nc shell.2019.nactf.com 31258`

- The20thDuck

Hint:
