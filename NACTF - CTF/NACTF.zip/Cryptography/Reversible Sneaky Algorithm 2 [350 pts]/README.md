Description:
Oligar was thinking about number theory at AwesomeMath when he decided to encrypt a message with RSA. As a mathematician, he made various observations about the numbers. He told Molly one such observation:

a^r ≡ 1 (mod n)

He isn't SHOR if he accidentally revealed anything by telling Molly this fact... can you decrypt his message? 

Source code, a and r, public key, and ciphertext are attached.

- The20thDuck

Hint:
