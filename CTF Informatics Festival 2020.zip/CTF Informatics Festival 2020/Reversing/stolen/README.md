# stolen [400 pts]

**Category:** Reversing
**Solves:** 4

## Description
>Lagi lagi, komputer kami teretas, hacker mencoba masuk ke sistem kami melalui salah satu service yang vulnerable, mereka mencuri flag kami dan menghapusnya, tetapi kami mempunyai rekaman capture jaringan pada saat insiden terjadi. Bisakah kamu menganalisa dan mengembalikan flag yang tercuri?

**Hint**
* -

## Solution

### Flag

