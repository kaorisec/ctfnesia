# Homoware [400 pts]

**Category:** Reversing
**Solves:** 6

## Description
>Salah satu komputer problem setter terkena Homoware, dan flag dari salah satu challenge terenkripsi, bisakah kamu mengembalikan flag, agar kompetisi CTF dapat berjalan dengan seharusnya?

**Hint**
* -

## Solution

### Flag

