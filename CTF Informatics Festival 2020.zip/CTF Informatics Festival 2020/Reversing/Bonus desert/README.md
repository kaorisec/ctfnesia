# Bonus desert [400 pts]

**Category:** Reversing
**Solves:** 6

## Description
>ada yang ngambang, tapi bukan warna kuning, apakah itu ?

**Hint**
* -

## Solution

### Flag

