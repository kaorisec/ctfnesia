# PHP Error [464 pts]

**Category:** Reversing
**Solves:** 4

## Description
>Someone obfuscate my code, but it getting errors

**Hint**
* AES Behavior is modified

## Solution

### Flag

