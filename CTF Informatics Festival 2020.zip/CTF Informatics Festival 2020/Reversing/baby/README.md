# baby [100 pts]

**Category:** Reversing
**Solves:** 16

## Description
>Baby reverse

Format Flag : IFEST2020{FLAG}

**Hint**
* -

## Solution

### Flag

