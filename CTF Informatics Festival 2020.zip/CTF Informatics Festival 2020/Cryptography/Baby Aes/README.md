# Baby Aes [176 pts]

**Category:** Cryptography
**Solves:** 10

## Description
>aes is to baby :P (updated file)


nc 103.146.203.17 5000

**Hint**
* -

## Solution

### Flag

