# Aesthethicc [100 pts]

**Category:** Cryptography
**Solves:** 15

## Description
>Cek hint

http://103.146.203.17:1337/

**Hint**
* ```
def encrypt(p):
    enc = AES.new(key, AES.MODE_OFB, iv)
	return enc.encrypt(pad(p))
```

## Solution

### Flag

