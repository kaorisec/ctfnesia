# Secret Note [496 pts]

**Category:** Web
**Solves:** 0

## Description
>Keep your note secret

http://103.146.203.17:3002/

**Hint**
* -

## Solution

### Flag

