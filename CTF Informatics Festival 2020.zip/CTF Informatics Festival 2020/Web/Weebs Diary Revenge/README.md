# Weebs Diary Revenge [304 pts]

**Category:** Web
**Solves:** 8

## Description
>ingat aku? iya aku. Web yang dulu kamu hek
Pada saat itu aku menangiddd, namun sekarang aku telah berlatih dan bertambah kuat datteboyyahhhh!!!!!

http://103.146.203.17:3000/

**Hint**
* -

## Solution

### Flag

