# Baby Python [176 pts]

**Category:** Web
**Solves:** 10

## Description
>Warming up with baby python

http://103.146.203.17:3003/

**Hint**
* -

## Solution

### Flag

