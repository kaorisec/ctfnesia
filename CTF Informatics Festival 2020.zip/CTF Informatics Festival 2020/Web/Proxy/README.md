# Proxy [436 pts]

**Category:** Web
**Solves:** 5

## Description
>I have a web proxy, can you exploit it ?

http://103.146.203.17:3001

**Hint**
* -

## Solution

### Flag

