# Balap PING liar [100 pts]

**Category:** Forensic
**Solves:** 16

## Description
>ini deskripsi

**Hint**
* -

## Solution

### Flag

