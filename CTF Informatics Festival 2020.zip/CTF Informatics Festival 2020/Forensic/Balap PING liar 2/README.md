# Balap PING liar 2 [100 pts]

**Category:** Forensic
**Solves:** 14

## Description
>

**Hint**
* -

## Solution

### Flag

