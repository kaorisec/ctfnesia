<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="span12">
            <form class="form-horizontal" action='' method="POST">
              <fieldset>
                <div id="legend">
                  <legend class="">Home</legend>
                  <legend class=""><a href="login.php">Login</a></legend>
                  <legend class=""><a href="register.php">Register</a></legend>
                </div>
                <div class="control-group">
                  <!-- Username -->
                  <label class="control-label"  for="username">Username</label>
                  <div class="controls">
                    <input type="text" id="username" name="username" placeholder="" class="input-xlarge">
                  </div>
                </div>
                <div class="control-group">
                  <!-- Password-->
                  <label class="control-label" for="password">Password</label>
                  <div class="controls">
                    <input type="password" id="password" name="password" placeholder="" class="input-xlarge">
                  </div>
                </div>
                <div class="control-group">
                  <!-- Button -->
                  <div class="controls">
                    <button class="btn btn-success" name="register">Register</button>
                  </div>
                </div>
              </fieldset>
            </form>
        </div>
    </div>
</div>


<?php

include "koneksi.php";

function filter($string){
        return preg_replace("/[^a-zA-Z]/", "", $string);
}

if (isset($_POST['register']))
{
    $uname  = filter($_POST['username']);
    $pass   = filter($_POST['password']);
    $level  = filter($_POST['level']);

    $query  = mysqli_query($konek, "INSERT INTO user VALUES('', '$uname', '$pass', '$level' ) ");

    if ($query)
    {
        echo "<script>alert('Data Sukses terdaftar, silahkan login'); window.location.href = 'login.php'</script>";
    }
    else
    {
        echo "<script>alert('Gagal')</script>";
    }
}

?>