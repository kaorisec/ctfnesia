<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="span12">
            <form class="form-horizontal" action='' method="POST">
              <fieldset>
                <div id="legend">
                  <legend class="">Home</legend>
                  <legend class=""><a href="login.php">Login</a></legend>
                  <legend class=""><a href="register.php">Register</a></legend>
                </div>
                <div class="control-group">
                  <!-- Username -->
                  <label class="control-label"  for="username">Username</label>
                  <div class="controls">
                    <input type="text" id="username" name="username" placeholder="" class="input-xlarge">
                  </div>
                </div>
                <div class="control-group">
                  <!-- Password-->
                  <label class="control-label" for="password">Password</label>
                  <div class="controls">
                    <input type="password" id="password" name="password" placeholder="" class="input-xlarge">
                  </div>
                </div>
                <div class="control-group">
                  <!-- Button -->
                  <div class="controls">
                    <button class="btn btn-success" name="login">Login</button>
                  </div>
                </div>
              </fieldset>
            </form>
        </div>
    </div>
</div>

<?php

    include "koneksi.php";

    if (isset($_POST['login']))
    {
        $uname  = $_POST['username'];
        $pass   = $_POST['password'];
        $level  = $_POST['level'];

        $query  = mysqli_query($konek, "SELECT * FROM user WHERE username = '$uname' AND password = '$pass' ");

        $data = mysqli_fetch_array($query);

        if (!$query)
        {
            echo "<script>alert('Apa sih lo hacker noob')</script>";
        }

        if ($data['level'] == "1337")
        {
            echo "Sukses Login, Selamat datang 1337,
            <br>Ini hadiah buat kamu <font color='red'>-- RAHASIA --</font>";
        }
        else
        {
            echo "Sukses Login, Selamat datang user";
        }

    }
?>