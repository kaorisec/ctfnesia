kunci = "BLUGCTF2k19"
flag = "***RAHASIA***"

if (len(flag) % len(kunci) != 0):
	n = len(kunci) - len(flag) % len(kunci)
	for i in range(n):
		flag += " "
q = []
for a in range(len(kunci)):
	i = a
	for b in range(len(flag)/len(kunci)):
		q.append(ord(flag[i])^ ord(kunci[a]))
		i += len(kunci)

enkripsi = ""
for j in range(len(q)):
	enkripsi +="%02x" % q[j]

f = open('enkripsiez.txt','w+')
f.write(enkripsi)
f.close()