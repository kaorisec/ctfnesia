Description:
Miss you my 0ld game :(

<img src="https://gaminggrad.files.wordpress.com/2014/01/2014-01-24_00008.jpg" style="height:30vh;">

Problem Setter : @sanstech_

Hint:
