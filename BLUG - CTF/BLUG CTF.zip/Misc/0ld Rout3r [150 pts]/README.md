Description:
Rezky, seorang network engineer, menemukan sebuah router yang telah usang yang merupakan router yang dulu dipakai diperusahaan nya, Evil Corp. Bantu rezky untuk melihat configurasi router tersebut

<a href="https://drive.google.com/open?id=15V_zQY8u9Ey2pA7i8F7mr6sNoqSIgWTR">0ld Rout3r</a>

Problem Setter : @sanstech_

Hint:
Username : hax0r
Password  : toor1337