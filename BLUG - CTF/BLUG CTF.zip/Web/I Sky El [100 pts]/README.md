Description:
I Sky El merupakan salah satu teknik yang mematikan yang ada didunia

<a href="http://iskyel.mypressonline.com/">Read More</a>

Problem Setter : @sanstech_

Hint:
