Description:
Skuyyyyy<br>
kenalan sama BlugOs, Robot Asisten kami <a href="http://31.220.52.164:8080/bot">Disini</a>

Problem Setter : @sanstech_

Hint:
