Description:
Ihsan, seorang web developer telah selesai membuat sebuah aplikasi.
Bisakah kamu meretasnya ?

<a href="http://ctfblug.mywebcommunity.org/index.php">Aplikasiku</a>

Problem Setter : @sanstech_

Hint:
Ingat !!!!!
nama file yang kamu cari adalah <b>flag.php</b>