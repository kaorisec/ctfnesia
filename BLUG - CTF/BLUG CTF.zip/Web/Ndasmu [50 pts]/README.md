Description:
Ndasmu lah cuk, oalah cok cok

<a href="http://31.220.52.164:8080/ndas/">Here</a>

Problem Setter : @sanstech_

Hint:
