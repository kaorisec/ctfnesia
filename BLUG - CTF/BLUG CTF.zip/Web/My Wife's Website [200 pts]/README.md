Description:
Ihsan sedang membuat sebuah website untuk istri nya yang tercinta, bisa kah kamu meretas nya ?

<a href="http://31.220.52.164:8080/mylove">Website Istri Ihsan</a>

Problem Setter : @sanstech_

Hint:
