Description:
Aku tuh ga suka ya dibanding bandingin dengan yang lain

<a href="http://31.220.52.164:8080/cmp/">Visit Me</a>

Problem Setter : @sanstech_

Hint:
