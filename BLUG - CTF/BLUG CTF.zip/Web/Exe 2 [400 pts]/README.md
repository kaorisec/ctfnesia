Description:
Kali ini Ihsan telah mengupgrade securitynya

<a href="http://blugctf.sportsontheweb.net/">Disini</a>

Problem Setter : @sanstech_

Hint:
