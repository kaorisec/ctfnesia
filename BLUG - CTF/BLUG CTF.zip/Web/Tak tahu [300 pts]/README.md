Description:
Novi, baru saja belajar tentang web security, bisakah kamu meretasnya ?

<a href="http://31.220.52.164:1337/">Website Novi</a>

Problem Setter : @sanstech_

Hint:
Saya suka include meng-include