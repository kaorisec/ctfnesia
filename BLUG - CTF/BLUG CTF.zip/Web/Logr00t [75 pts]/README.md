Description:
nge-Logr00t kuy di javaskuy

<a href="http://31.220.52.164:8080/logroot/">Skuyyyy</a>

Problem Setter : @sanstech_

Hint:
