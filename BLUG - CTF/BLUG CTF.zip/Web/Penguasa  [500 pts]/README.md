Description:
Jadilah Penguasa !

<a href="http://blugnew.atwebpages.com/index.php">Kunjungi</a>

Problem Setter : @sanstech_

Hint:
