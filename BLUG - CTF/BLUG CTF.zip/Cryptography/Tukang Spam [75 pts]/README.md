Description:
Admin1337 adalah tukang spam di shi*tpost bacotan hacker masa kini. bisakah kamu menerjemahkan spam nya ? <br>

Format Flag : BLUG{flag} <br>

Author : @artharezkyy

Hint:
