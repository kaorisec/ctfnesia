Description:
Kali ini sama aja seperti sebelum nya tetapi ini tidak recursive melainkan tinggal di decode saja :) <br>

1. QkxVR3t3dGZfZmxhZ19wYWxzdX0== <br><br>
2. ==9RHe09VZzNnclZ3My9VesFzc0U2X0YzXlNHNit3RVxkQ

Hint:
