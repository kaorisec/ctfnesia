Description:
WTF javascript apaan ini,  bisakah kamu menerjemahkan nya ?

Hint:
