Description:
yupspp mari kita coba pecahkan kode di bawah ini lagi :) <br>

Key : BLUG <br><br>
CWOM{wtakoplk_llmotvco} <br>

Author : @artharezky

Hint:
