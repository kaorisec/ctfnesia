Description:
<br>3Dimensi<br>

enkripsi : k1XRhxvbwvFex83ywXkDPzlwZyLRtQ5Q <br>
Key : BLUG <br>
IV    :  1337 <br>

Format Flag : BLUG{example}<br>

Problem Setter : @artharezky <br>

Hint:
