Description:
Jangan sampai berpaling dari nya :)

ecruoS_nepO_oG_aisenodni : umak kutnu galf ini nad acabmem halet hisakamiret .igabreb nad rajaleb nitur nataigek nagned mataB atoK id rasebret xuniL anuggnep satinumok halada GULB puorG resU xuniL mataB

Format Flag : BLUG{xxxxxx}

Hint:
