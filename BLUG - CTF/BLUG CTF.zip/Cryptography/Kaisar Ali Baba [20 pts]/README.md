Description:
kali ini kode rahasia dari kaisar ali baba yang harus di pecahkan <br>

AKTF{Q4iz_B4drzq_4kh_a4az} <br>

Format Flag : BLUG{xxxxxx}

Hint:
