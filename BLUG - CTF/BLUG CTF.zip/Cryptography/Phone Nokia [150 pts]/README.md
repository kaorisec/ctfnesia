Description:
Masih inget sama aku ? <br>
 dulu masih jaman jamannya rame sms an :) <br>
sekarang aku kembali untuk mengisi soal ctf bikin nostalgia kan. <br>
Format Flag : BLUG{lowercase}
<br><br>
<img src="https://www.yorku.ca/mack/chapter5-f2.jpg">

Hint:
