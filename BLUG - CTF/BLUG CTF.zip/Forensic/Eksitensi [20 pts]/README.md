Description:
<br>File System telah di ubah. 
<br> bisakah kamu menemukan flag nya  ? 
<br><br>
Problem Setter : @artharezkyy
<br>

Hint:
