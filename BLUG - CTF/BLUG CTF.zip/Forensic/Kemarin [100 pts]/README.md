Description:
<br>Kemarin aku menyembunyikan sesuatu barang. tapi aku lupa barang itu ada dimana. saya coba pikir-pikir tidak ingat juga. bisa kah kamu membantu saya?<br>

Problem Setter : @artharezkyy <br>

Hint:
