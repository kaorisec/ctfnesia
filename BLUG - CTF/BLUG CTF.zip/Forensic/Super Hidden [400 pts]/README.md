Description:
<br>bisakah kamu membantu Tom untuk menemukan Jerry?<br>

Format Flag : BLUG{example} <br>

Problem Setter : @artharezkyy <br>

Hint:
