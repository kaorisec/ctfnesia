Description:
<br>Tools Steganography mungkin bisa membantu anda.<br>

Problem Setter : @artharezkyy <br>

Hint:
