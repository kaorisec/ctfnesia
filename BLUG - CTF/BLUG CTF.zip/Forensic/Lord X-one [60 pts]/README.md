Description:
<br>saya menyembunyikan file di gambar lagi, bisa kah kamu mengektraknya ?<br>

Problem Setter : @artharezkyy <br>

Hint:
