Description:
<br>Oh Tuhan kucinta dia<br>
Kusayang dia, rindu dia, inginkan dia<br>
Utuhkanlah rasa cinta di hatiku<br>
Hanya padanya<br>
Untuk dia<br>

Problem Setter : @artharezkyy <br>

Hint:
