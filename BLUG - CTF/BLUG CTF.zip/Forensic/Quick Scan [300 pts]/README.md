Description:
<br>Manual itu sangat membutuhkan waktu lama.<br>

tapi admin ada cara mempercepat mendapatkan nya.<br>

kalo scan manual adalah jalan ninjamu. semangat proses tidak mengkhianati hasil :)

Problem Setter : @artharezkyy <br>

Hint:
