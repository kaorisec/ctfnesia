Description:
<br>Reza arap oktavian<br>
Gamers ganteng idaman<br>
Nakal tapi tampan<br>
Youpp<br>
Itu verse dari guenext K'jov<br>
Youtube Youtube Youtube lebih dari TV?<br>
Youtube Youtube Youtube lebih dari TV?<br>

Format Flag : BLUG{flag}<br>

Problem Setter : @artharezkyy <br>

Hint:
