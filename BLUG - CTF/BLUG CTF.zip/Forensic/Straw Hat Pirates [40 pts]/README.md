Description:
<br>Nami seorang navigasi memberitahu informasi kepada Captain Luffy bahwa meta data informasi nya telah di ambil oleh kurohige.<br>

bisakah anda membantu mengambil meta data informasi itu di tangan kurohige?
<br><br>
Problem Setter : @artharezkyy

Hint:
