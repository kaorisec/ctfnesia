Description:
Setelah berhasil menemukan cara untuk mendapatkan masker secara gratis, Anda melaporkan bug tersebut secara bertanggung jawab ke pemilik web. Setidaknya, ada 2 bug yang dilaporkan. Pemilik web tersebut pun telah melakukan patching untuk bug yang diketahui.

Sayangnya, toko masker tersebut tidak punya program bug bounty sehingga Anda hanya dikasih 2M (makasih mas). Tetapi, Anda kemudian ditawarkan proyek untuk melakukan security code review pada aplikasi tersebut. Karena outsource, pemilik web tidak dapat memberikan source code secara keseluruhan.

Dapatkah Anda meretas kembali toko masker ini untuk mendapatkan masker gratis? Flag akan ditampilkan ketika Anda berhasil membeli 100 buah masker N99.

https://tokomasker3.web.cyber.jawara.systems/

Hint:
