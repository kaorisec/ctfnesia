Description:
Setelah melakukan proses recon, Anda menemukan <a href="https://extramile.web.cyber.jawara.systems/">halaman dashboard admin</a> tersembunyi suatu perusahaan. Secara intuitif, Anda mencoba untuk memasukkan admin:admin untuk login dan ternyata bisa! Sayangnya tidak ada apa-apa di dalam dashboard tersebut.

Anda ingin melaporkan temuan Anda untuk mendapatkan bounty namun Anda khawatir kalau laporan Anda tidak eligible karena tidak ada apa-apa di dalam dashboard tersebut. Oleh karena itu, Anda ingin mencoba untuk menempuh extra mile dan mencoba mencari hal lain di aplikasi web tersebut untuk mendemonstrasikan impact setinggi mungkin.

Hint: Sepertinya Anda bisa mendapatkan suatu informasi dengan membuat error web tersebut.

Hint:
