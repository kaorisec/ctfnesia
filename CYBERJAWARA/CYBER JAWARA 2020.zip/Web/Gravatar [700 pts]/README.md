Description:
Gravatar adalah salah satu penyedia layanan avatar yang sangat banyak digunakan walaupun sekarang pamornya kalah turun semenjak adanya layanan integrasi akun dan avatar melalui OAuth populer seperti Google dan Facebook.

https://gravatar.web.cyber.jawara.systems/

Hint:

- `gravatar_image_path = urllib.parse.urljoin(gravatar_url, path)`
- `whois $(dig +short gravatar.web.cyber.jawara.systems)`

Hint:
