Description:
Pada masa pandemi Covid-19 ini, seluruh orang yang berpergian ke luar rumah wajib menggunakan masker. Menggunakan masker secara kolektif terbukti dapat menurunkan angka penyebaran virus.

Penjual masker pun mendapatkan peningkatan pendapatan (stonks). Selain berjualan secara langsung, banyak juga penjual masker yang menggunakan online shop untuk berjualan.

Kebetulan, stok masker Anda sudah habis. Anda ingin membeli masker di salah satu toko masker online yang menyediakan berbagai macam masker. Sembari membeli masker, Anda ingin melakukan security testing (karena sudah kebiasaan).

Anda pun penasaran, dapatkah Anda mengakali toko masker online tersebut supaya Anda bisa mendapatkan masker secara gratis? Flag akan ditampilkan ketika Anda sudah berhasil membeli 100 buah masker N99.

https://tokomasker1.web.cyber.jawara.systems/

Hint:
