Description:
Salah satu cara untuk memeriksa integritas sebuah data adalah dengan mengecek checksum. Terkadang checksum juga digunakan untuk memeriksa apakah suatu input yang digunakan dalam proses dekripsi adalah valid atau tidak valid.

Layanan berikut akan memeriksa suatu ciphertext untuk menentukan apakah input tersebut valid atau tidak valid.


`nc net.cyber.jawara.systems 3002`

Hint:
