Description:
CaaS (Crypto as a Service) adalah layanan yang dapat digunakan untuk mengenkripsi suatu plain text. Kode sumber layanan ini bisa diunduh di bawah.

Encrypted string berikut adalah flag yang sudah dienkripsi dengan layanan yang sama.

`pJ8GmKrvZS0dO3LPfcvjXrbIRusaEF/wb/Ps8ENwmH0fvkcIau74mSnZPwBvbyMeXyUrAvDBY+McaztsZsM+nw==`

Anda harus mendapatkan plain text dari flag tersebut.

`nc net.cyber.jawara.systems 3001`

Hint:
