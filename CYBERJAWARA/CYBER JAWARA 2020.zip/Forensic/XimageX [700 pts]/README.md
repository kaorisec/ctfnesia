Description:
Steganografi mungkin terkadang menyebalkan, tetapi di Cyber Sea Game ada soal steganografi jadi kalian harus bisa :( 

Hint: LSB

Hint:
