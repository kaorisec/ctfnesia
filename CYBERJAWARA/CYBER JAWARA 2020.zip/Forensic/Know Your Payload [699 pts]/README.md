Description:
Jangan sembarangan menggunakan exploit orang.

Hint:
