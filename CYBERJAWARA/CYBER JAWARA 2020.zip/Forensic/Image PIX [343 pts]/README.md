Description:
Secret Message From Jim Moriarty to Holmes in Image

Hint:
