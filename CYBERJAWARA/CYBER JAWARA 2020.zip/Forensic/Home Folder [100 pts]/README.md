Description:
Di saat melakukan forensic pada sistem yang menggunakan OS Ubuntu, Anda menemukan home folder dari salah satu user berisi sesuatu yang mencurigakan. Dapatkah Anda mendapatkan berkas flag.txt dari situ?

Hint:
