Description:
Permainan Snake dari Cyber Jawara sebelum-sebelumnya kembali lagi! Kali ini sudah menggunakan GUI yang dibuat dengan Java.

Flag akan ditampilkan ketika skor permainan mencapai 8172. Tetapi, apakah ularnya akan muat?

Hint: Mengubah skor secara langsung menggunakan aplikasi semacam cheat engine tidak akan mengeluarkan flag.

Hint:
