Description:
Number Home Sherlock Holmes ?

Please check on the File

Download home : https://drive.google.com/file/d/14P7xZ4XIsEm6HU5WMvOVw6E0BFRH6CuH/view

Hint:
