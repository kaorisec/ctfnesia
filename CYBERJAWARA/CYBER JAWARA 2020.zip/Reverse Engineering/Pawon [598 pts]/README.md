Description:
Yet another reverse engineering challenge

Hint:
