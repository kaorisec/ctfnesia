Description:
Teman Anda baru belajar menggunakan Go dan membuat sebuah program sederhana. Namun, program tersebut crash ketika dijalankan padahal ia yakin programnya benar.

Ia meminta bantuan Anda untuk memeriksa apa yang salah. Namun, bukannya memberikan source code, teman Anda malah memberikan program yang sudah di-compile.

Dapatkah Anda memeriksa apa yang salah dan mendapatkan output yang diekspektasikan? Flag dari soal ini adalah `CJ2020{output}`

[Unduh program](https://drive.google.com/file/d/1T0Cmjr4Ul1orltMOfNwf9cyyUoVpTTxM/view?usp=sharing)

Hint:
