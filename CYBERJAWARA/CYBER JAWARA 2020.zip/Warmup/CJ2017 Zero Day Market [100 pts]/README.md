Description:
Ini adalah salah satu contoh soal Cyber Jawara 2017 dengan nama Zero Day Market yang sudah dimodifikasi sedikit. Pembahasan dari soal yang terdahulu dapat dicari di internet.

`nc pwn.cyber.jawara.systems 1001`

Hint:
