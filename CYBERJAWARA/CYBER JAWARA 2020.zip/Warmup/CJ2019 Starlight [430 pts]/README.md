Description:
Ini adalah salah satu contoh soal Cyber Jawara 2019 dengan nama Starlight yang sudah dimodifikasi sedikit. Pembahasan dari soal yang terdahulu dapat dicari di internet.

`nc pwn.cyber.jawara.systems 1002`

Hint:
