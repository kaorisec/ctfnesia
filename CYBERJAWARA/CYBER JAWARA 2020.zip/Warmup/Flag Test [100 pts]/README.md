Description:
Balik string berikut dan masukkan sebagai flag:

}gnirocs_cimanyd_tail_nad_galf_timbus_niaboc_taub_ini{0202JC

Hint:
