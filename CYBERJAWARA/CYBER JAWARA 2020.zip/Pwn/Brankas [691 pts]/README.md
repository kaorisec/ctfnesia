Description:
Kali ini, Anda harus membongkar brankas digital. Brankas ini cukup unik. Brankas memiliki 30 lapis. Di setiap lapis, Anda harus memasukkan PIN berupa 5 digit angka yang di-generate secara random pada setiap Anda mengakses brankas. Untuk setiap PIN yang dimasukkan, brankas akan menampilkan jumlah posisi digit yang sudah benar. Untuk proteksi, Anda hanya bisa menebak PIN sebanyak 10 kali untuk setiap lapis.

Sebagai contoh, misalnya PIN untuk lapisan 1 brankas adalah 50123. Interaksinya adalah sebagai berikut:

> PIN: 01234

> Benar: 0

> PIN: 12123

> Benar: 3

> PIN: 00123

> Benar: 4

> PIN: 50123

> Benar: 5

> Lapisan 1 terbuka

`nc pwn.cyber.jawara.systems 13374`

Hint:
