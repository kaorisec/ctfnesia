Description:
Mari bermain permainan yang sulit! Diberikan petak 4x4. Di setiap giliran, Anda harus memilih satu petak yang aman dari ranjau. Tentunya posisi ranjau selalu diacak layaknya game minesweeper. Flag akan ditampilkan ketika Anda berhasil bertahan hingga 8 giliran.

`nc pwn.cyber.jawara.systems 13373`

Hint:
