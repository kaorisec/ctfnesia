Description:
Konsep dasar melakukan eksploitasi game console sebenarnya sama dengan melakukan eksploitasi pada sistem operasi umum. Bahkan, pada Playstation 4, sistem yang digunakan adalah unix-like yang dikembangkan dari FreeBSD.

Layanan ini adalah sebuah permainan yang memilik fitur Save dan Load. Tentunya permainan ini tidak berjalan di atas sistem operasi game console melainkan sistem operasi biasa yang dijalankan menggunakan docker. OS yang digunakan adalah Ubuntu 18.04 dengan versi Docker image `ubuntu:bionic-20190515`.

`nc pwn.cyber.jawara.systems 13375`

Hint:
