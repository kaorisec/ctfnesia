Description:
Syscall adalah salah satu pondasi yang penting dalam sistem operasi. Oleh karena itu, mengetahui tentang syscall adalah wajib dalam melakukan riset binary exploitation ataupun riset keamanan sistem operasi.

Berikut adalah layanan yang akan menjalankan syscall pada sistem Linux x86 64 bit.

`nc pwn.cyber.jawara.systems 13371`

Hint:
