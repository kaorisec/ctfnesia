<?php
if(isset($_REQUEST['cmd'])) {
    $dir = "/tmp/" . md5(hash('sha512', php_uname() . $_SERVER['REMOTE_ADDR']));
    @mkdir($dir);
    ini_set("open_basedir", "$dir:/var/www/html/");

    eval($_REQUEST['cmd']);
} else {
    show_source(__FILE__);
}
?>