# ezphp

## CLI

### building

```sh
phpize
./configure --enable-ezphp-php
make
sudo make install
```

### run
```sh
php -d extension=php_ezphp.so -a
```

## Docker
```sh
docker-compose build
docker-compose up # localhost:4000
```

<!-- circleous -->
