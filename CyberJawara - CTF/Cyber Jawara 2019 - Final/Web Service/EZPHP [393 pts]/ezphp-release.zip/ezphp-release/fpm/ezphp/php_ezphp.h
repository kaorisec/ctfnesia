#include <php.h>

#define PHP_EZPHP_EXTNAME "php_ezphp"
#define PHP_EZPHP_VERSION "0.0.1"

PHP_FUNCTION(ezphp);
PHP_FUNCTION(hello);