#include "php_ezphp.h"

zend_function_entry ezphp_functions[] = {
    PHP_FE(ezphp, NULL)
    PHP_FE(hello, NULL)
    {NULL, NULL, NULL}
};

zend_module_entry ezphp_module_entry = {
    STANDARD_MODULE_HEADER,
    PHP_EZPHP_EXTNAME,
    ezphp_functions,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    PHP_EZPHP_VERSION,
    STANDARD_MODULE_PROPERTIES
};

ZEND_GET_MODULE(ezphp)

PHP_FUNCTION(ezphp) {
    zend_string *str;
    zend_long len;

    ZEND_PARSE_PARAMETERS_START(2, 2)
        Z_PARAM_STR(str)
        Z_PARAM_LONG(len)
    ZEND_PARSE_PARAMETERS_END();

    if (ZSTR_LEN(str) == 0) {
        php_error_docref(NULL, E_WARNING, "Empty string");
        RETURN_FALSE;
    } else {
        str->len = len;
        RETURN_TRUE;
    }
}

PHP_FUNCTION(hello) {
    zend_string *str;

    ZEND_PARSE_PARAMETERS_START(1, 1)
        Z_PARAM_STR(str)
    ZEND_PARSE_PARAMETERS_END();

    puts(str->val);

    RETURN_TRUE;
}