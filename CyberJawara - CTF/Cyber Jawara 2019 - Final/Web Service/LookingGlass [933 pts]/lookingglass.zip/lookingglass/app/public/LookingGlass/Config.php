<?php
/**
 * LookingGlass - User friendly PHP Looking Glass
 *
 * @package     LookingGlass
 * @author      Nick Adams <nick@iamtelephone.com>
 * @copyright   2015 Nick Adams.
 * @link        http://iamtelephone.com
 * @license     http://opensource.org/licenses/MIT MIT License
 * @version     1.3.0
 */

// IPv4 address
$ipv4 = '127.0.0.1';
// IPv6 address (can be blank)
$ipv6 = '';
// Rate limit
$rateLimit = (int) '0';
// Site name (header)
$siteName = 'LookingGlass';
// Site URL
$siteUrl = 'http://localhost/';
// Server location
$serverLocation = 'Jakarta';
// Test files
$testFiles = array();
$testFiles[] = '5';
// Theme
$theme = 'cerulean';
