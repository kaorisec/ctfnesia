const axios = require('axios');
const { joinPath, baseURL } = require('../utils/path');

axios.defaults.timeout = 1000;
const notesBaseURL = joinPath(baseURL, 'notes/');

exports.getNotes = async function(req, res, next) {
    try {
        const response = await axios({
            method: 'get',
            url: notesBaseURL,
            headers: {'X-User-ID': req.user.id},
        });
        return res.json(response.data);
    } catch (err) {
        if (err.response) {
            return res.status(err.response.status).json(err.response.data);
        }
        return res.status(500);
    }
}

exports.getNote = async function(req, res, next) {
    try {
        const response = await axios({
            method: 'get',
            url: joinPath(notesBaseURL, req.params.id),
            headers: {'X-User-ID': req.user.id},
        });
        return res.json(response.data);
    } catch (err) {
        if (err.response) {
            return res.status(err.response.status).json(err.response.data);
        }
        return res.status(500);
    }
}

exports.createNote = async function(req, res, next) {
    try {
        const { content } = req.body;
        const response = await axios({
            method: 'post',
            url: notesBaseURL,
            headers: {'X-User-ID': req.user.id},
            data: {content},
        });
        return res.json(response.data);
    } catch (err) {
        if (err.response) {
            return res.status(err.response.status).json(err.response.data);
        }
        return res.status(500);
    }
}
