import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import blue from '@material-ui/core/colors/blue';

import CssBaseline from '@material-ui/core/CssBaseline';
import Container from '@material-ui/core/Container';
import Box from '@material-ui/core/Box';

import Navbar from './components/Navbar';
import Notes from './components/Notes';
import Login from './components/Login';
import Register from './components/Register';
import Notification from './components/Notification';

import AuthCtx from './contexts/AuthContext';
import NotificationCtx from './contexts/NotificationContext';

const theme = createMuiTheme({
  palette: {
    primary: {
      main: '#800020',
    },
    secondary: blue,
  },
});

export default function App() {
  return (
    <AuthCtx>
      <NotificationCtx>
        <MuiThemeProvider theme={theme}>
          <Router>
            <CssBaseline />
            <Navbar />
            <Container maxWidth="md">
              <Box mt={2}>
                <Route exact path="/" component={Notes} />
                <Route exact path="/login" component={Login} />
                <Route exact path="/register" component={Register} />
              </Box>
            </Container>
            <Notification />
          </Router>
        </MuiThemeProvider>
      </NotificationCtx>
    </AuthCtx>
  );
};
