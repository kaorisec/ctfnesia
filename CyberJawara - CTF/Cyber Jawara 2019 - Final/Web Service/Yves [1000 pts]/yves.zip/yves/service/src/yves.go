package yves

import (
	"net/http"

	"github.com/gorilla/mux"

	"yves/database"
	"yves/handler"
	"yves/middleware"
)

type Yves struct {
	Router http.Handler
}

func NewYves() *Yves {
	database.Init()
	handler.Init()

	api := handler.APIHandler

	router := mux.NewRouter().StrictSlash(false)
	apiRouter := router.PathPrefix("/api").Subrouter()

	authMiddleware := middleware.AuthMiddleware

	userRouter := apiRouter.PathPrefix("/users").Subrouter()
	userRouter.HandleFunc("/", api.Register).Methods("POST")
	userRouter.HandleFunc("/{username:[a-zA-Z0-9]+}", api.GetUser).Methods("GET")

	productsRouter := apiRouter.PathPrefix("/notes").Subrouter()
	productsRouter.HandleFunc("/", authMiddleware(api.GetNotes)).Methods("GET")
	productsRouter.HandleFunc("/", authMiddleware(api.CreateNote)).Methods("POST")
	productsRouter.HandleFunc("/{id:[0-9]+}", authMiddleware(api.GetNote)).Methods("GET")

	return &Yves{router}
}
