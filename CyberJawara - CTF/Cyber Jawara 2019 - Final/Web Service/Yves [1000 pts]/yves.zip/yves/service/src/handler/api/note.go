package api

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"

	"yves/database"
	"yves/model"
	"yves/response"
)

func (h Handler) GetNotes(w http.ResponseWriter, r *http.Request) {
	userID := r.Context().Value("UserID").(uint64)
	user := model.User{
		ID: userID,
	}
	var notes []model.Note
	if result := database.MySQL.Model(&user).Related(&notes); result.Error != nil {
		response.Write(w, response.BuildError(response.ErrInternalServerError), http.StatusInternalServerError)
		return
	}
	response.Write(w, response.BuildSuccess(notes), http.StatusOK)
}

func (h Handler) GetNote(w http.ResponseWriter, r *http.Request) {
	noteID, err := strconv.ParseInt(mux.Vars(r)["id"], 10, 64)
	if err != nil {
		response.Write(w, response.BuildError(err), http.StatusBadRequest)
		return
	}

	var note model.Note
	if result := database.MySQL.First(&note, noteID); result.Error != nil {
		response.Write(w, response.BuildError(response.ErrInternalServerError), http.StatusInternalServerError)
		return
	}

	userID := r.Context().Value("UserID").(uint64)
	if userID != note.UserID {
		response.Write(w, response.BuildError(response.ErrForbidden), http.StatusForbidden)
		return
	}
	response.Write(w, response.BuildSuccess(note), http.StatusOK)
}

func (h Handler) CreateNote(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()

	var noteRequest model.Note
	err := json.NewDecoder(r.Body).Decode(&noteRequest)
	if err != nil {
		response.Write(w, response.BuildError(err), http.StatusBadRequest)
		return
	}

	userID := r.Context().Value("UserID").(uint64)
	note := model.Note{
		UserID:  userID,
		Content: noteRequest.Content,
	}
	if result := database.MySQL.Create(&note); result.Error != nil {
		response.Write(w, response.BuildError(response.ErrInternalServerError), http.StatusInternalServerError)
		return
	}
	response.Write(w, response.BuildSuccess(nil), http.StatusOK)
}
