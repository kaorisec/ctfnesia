package middleware

import (
	"context"
	"net/http"
	"strconv"

	"yves/response"
)

type Middleware func(w http.ResponseWriter, r *http.Request)

func AuthMiddleware(handle Middleware) Middleware {
	return func(w http.ResponseWriter, r *http.Request) {
		userID, err := getUserID(r)
		if err != nil {
			response.Write(w, response.BuildError(response.ErrUnauthorized), http.StatusUnauthorized)
			return
		}

		ctx := r.Context()
		ctx = context.WithValue(ctx, "UserID", userID)
		handle(w, r.WithContext(ctx))
	}
}

func getUserID(r *http.Request) (uint64, error) {
	headerUserID := r.Header.Get("X-User-ID")
	userID, err := strconv.ParseUint(headerUserID, 10, 64)
	if err != nil {
		return 0, err
	}
	return userID, nil
}
