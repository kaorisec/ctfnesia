package handler

import (
	"yves/handler/api"
)

var (
	APIHandler api.Handler
)

func Init() {
	APIHandler = api.Handler{}
}
