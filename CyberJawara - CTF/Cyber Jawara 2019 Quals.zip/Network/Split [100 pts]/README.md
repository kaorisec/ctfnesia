Description:
Suatu berkas bisa dipisahkan menjadi beberapa bagian agar dapat diunduh secara terpisah. Bagaimana cara menyatukannya?

https://drive.google.com/open?id=1mLGqr66XlGono-mOaSv3q51H1DeobSJf


*Problem setter: farisv*

Hint:
