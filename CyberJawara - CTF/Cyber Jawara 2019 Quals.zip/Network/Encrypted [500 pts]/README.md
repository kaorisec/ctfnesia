Description:
IDS kami mendeteksi adanya reverse shell pada mesin Windows kami. Namun, kami tidak dapat mengetahui apa yang sebenarnya attacker lakukan. Di saat yang sama, sepertinya attacker mengakses sesuatu melalui komunikasi yang terenkripsi. Dapatkah Anda menganalisis apa yang attacker lakukan?

https://drive.google.com/open?id=1fAvYQ6ImWFgftj5cH1hBRp9L5HYlwnYZ

Hint:
- mimikatz
- Port 3389



*Problem setter: farisv*

Hint:
