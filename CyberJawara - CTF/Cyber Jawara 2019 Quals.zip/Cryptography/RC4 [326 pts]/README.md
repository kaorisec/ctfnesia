Description:
Pecahkan stream cipher berikut.

https://drive.google.com/open?id=1MmA-EwqJJZzY0bymcp7aJRLmA8bgFu4f

**UPDATE**

Mohon maaf ada berkas yang kurang pada archive di atas. Berikut adalah berkas yang Anda butuhkan https://drive.google.com/open?id=1xmTbm31bNIkv-DLIkqwc-w_YKQtwyF13 


*Problem setter: farisv*

Hint:
