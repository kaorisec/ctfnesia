Description:
Kali ini tidak ada private key untuk Anda.

https://drive.google.com/open?id=1kZ6PP7ipHNQnKFeo5gAY5D7PYkcn2IBK

*Problem setter: farisv*

Hint:
