Description:
Cek apakah Anda familiar dengan kriptografi.

https://drive.google.com/open?id=1tiOQLshZF5UcUJsp2VMkVYB6nY8UGVYq


*Problem setter: farisv*

Hint:
