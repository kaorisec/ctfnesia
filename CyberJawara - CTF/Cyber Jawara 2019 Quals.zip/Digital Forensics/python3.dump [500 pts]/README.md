Description:
Dukungan untuk Python 2 akan segera berakhir. Attacker pun mulai lebih sering menggunakan Python 3 termasuk pada saat post exploitation. Berikut adalah memory dump dari suatu process Python 3 yang mencurigakan pada server Linux. Dapatkah Anda melakukan forensik dan mengekstraksi informasi berharga dari situ?

https://drive.google.com/open?id=1NQ5PUt8GL-yHZBVlxJ6QdYCxraefD1ZJ


*Problem setter: farisv*

Hint:
