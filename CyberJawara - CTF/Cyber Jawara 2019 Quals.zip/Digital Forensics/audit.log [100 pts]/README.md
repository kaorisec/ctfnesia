Description:
Seseorang telah meng-compromise server Linux kami. Untungnya kami sebelumnya sudah memasang auditd daemon guna melakukan logging untuk syscall tertentu. Dapatkah Anda menganalisis apa yang attacker lakukan dengan melakukan forensik pada berkas audit.log ini?

https://drive.google.com/open?id=18fGxvd9u_hxn4A7Fd1_sbDIs-n_SMp7y


*Problem setter: farisv*

Hint:
