Description:
Walaupun saat ini sistem 64 bit dipakai di mana-mana, beberapa sistem masih harus menggunakan OS 32 bit (misalnya untuk IoT devices seperti Raspberry Pi). Retaslah aplikasi berikut yang merupakan ELF 32 bit yang statically-linked.

https://drive.google.com/open?id=15RCO1csb7fihQNfiC24J2j6oEXI9nPPC

`nc 203.34.119.237 11339`


*Problem setter: farisv*

Hint:
