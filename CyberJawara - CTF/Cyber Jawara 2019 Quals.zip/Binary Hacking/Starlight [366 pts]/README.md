Description:
Dapatkah Anda memahami kode C dari binary ini dan meretas network service yang menjalankan binary tersebut?

https://drive.google.com/open?id=1Kuj6sTWI4WE4mLFL4W8hdH5MEB2JjIiX

`nc 203.34.119.237 11337`


*Problem setter: farisv*

Hint:
