Description:
Pada Cyber Jawara tahun lalu, peserta diharuskan melakukan cracking terhadap program Snake agar mendapatkan skor tertentu untuk mendapatkan flag. Tahun ini Anda harus melakukan cracking terhadap  game Snake yang berbeda yang sudah diproteksi dan Anda harus mencapai skor **tepat 133333337** untuk mendapatkan flag.

Note:
- Game ini berbentuk aplikasi ELF yang dapat dijalankan di terminal Linux 64 bit.
- Gunakan 'w', 'a', 's', dan 'd' untuk bergerak.

https://drive.google.com/open?id=12BbU4WUObvPMDJ9rwiWkMN1dkFF0pXe5


*Problem setter: farisv*

Hint:
