Description:
Entah mengapa Gowon selalu gagal menjalankan binary ini...

https://drive.google.com/open?id=1l7jjYYloRFVTSRHo3Qm4tAt0U714o4RX


*Problem setter: visat*

Hint:
