Description:
Haseul diberikan sebuah binary untuk latihan reverse engineering. Bantulah dia!

https://drive.google.com/open?id=1kmugcTNqjVDRc8gUnRYfw_mAUYxGJ97a


*Problem setter: visat*

Hint:
