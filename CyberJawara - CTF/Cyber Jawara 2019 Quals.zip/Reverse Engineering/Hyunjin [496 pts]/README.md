Description:
Hyunjin membuat sebuah key checker di web. Akan tetapi, dia merasa JavaScript terlalu lambat sehingga dia beralih ke WebAssembly. Suatu hari dia lupa key miliknya. Bantulah Hyunjin mendapatkan key-nya kembali!

Catatan:
- Hati-hati karena browser dapat *hang* walaupun telah dimasukkan dengan flag yang benar.
- Perhatikan overflow.

http://203.34.119.237:40000/


*Problem setter: visat*

Hint:
