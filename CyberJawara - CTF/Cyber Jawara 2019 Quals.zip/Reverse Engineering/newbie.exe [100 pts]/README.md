Description:
Mari belajar reverse engineering dengan mencoba memecahkan program dengan kode yang sederhana.

https://drive.google.com/open?id=1WLkMlyKfAG6Xr_XbVnM7QVHSZrXqks0M


*Problem setter: farisv*

Hint:
