Description:
Olivia membuat web untuk melakukan konversi gambar ke monokrom karena dia hanya menyukai warna hitam dan putih. Dia sangat yakin web buatannya aman.

Tugasmu adalah memberinya pelajaran bahwa tidak ada sistem yang aman! 👊😎

Hint:
- CVE-2019-9947

https://drive.google.com/open?id=1guIsdp-F57_hoh6KPIpfTmym9EWew4uX

http://203.34.119.237:50004/


*Problem setter: visat*

Hint:
