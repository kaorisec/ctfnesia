Description:
Heejin membuat web untuk menjual albumnya dalam versi digital. Album paling eksklusif, Flag, sangatlah mahal dan hanya dapat dibeli oleh 1337 haxor. Dapatkah kamu membelinya?

https://drive.google.com/open?id=1cJPV4_bjRzMO_woqrx6_2vHp7UFsXzAY

http://203.34.119.237:50002/


*Problem setter: visat*

Hint:
