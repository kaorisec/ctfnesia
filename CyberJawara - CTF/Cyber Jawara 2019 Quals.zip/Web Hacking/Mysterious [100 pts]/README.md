Description:
Kami menemukan PHP web shell misterius berikut di server kami. Ketika dibuka, yang kami lihat hanyalah **HTTP 500 Internal Server Error**.

https://drive.google.com/open?id=1aBamhFxPVnVScjnyO6qPHA2nxYnKeE0f

http://203.34.119.237:50000/shell.php

Note:
**Anda harus melakukan sesuatu agar shell tersebut tidak error.** Harap hanya kontak panitia apabila server benar-benar tidak dapat diakses (timeout atau unreachable).


*Problem setter: farisv*

Hint:
