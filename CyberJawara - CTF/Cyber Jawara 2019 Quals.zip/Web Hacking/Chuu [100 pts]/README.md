Description:
Chuu membuat web ChuuTube dengan teknologi terbaru yang sedang *hype* saat ini. Namun, sekilas web tersebut hanya berisi koleksi video musik dan fancamnya saja 🤔

http://203.34.119.237:50003/


*Problem setter: visat*

Hint:
