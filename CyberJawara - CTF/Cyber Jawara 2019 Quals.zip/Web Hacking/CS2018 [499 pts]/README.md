Description:
Karena ada tim yang sudah solve soal-soal yang dikeluarkan pada 6 jam pertama, maka kami deploy soal Cyber Sea Game tahun lalu (dengan sedikit modifikasi) sebagai tambahan.

https://drive.google.com/file/d/1fWVrQUlrAtIxR8a2-PjkMJe1Ikn-EVyd/view

Hint:
- Nama soal ini pada Cyber Sea Game tahun lalu adalah "readfile"

http://203.34.119.237:50005/

Hint:
