Description:
Web ini baru saja diretas sehingga pemiliknya mengganti tampilan halamannya menjadi *under construction*. Dapatkah Anda menganalisis sebenarnya apa yang terjadi sebelumnya di web ini?

http://203.34.119.237:50001/


*Problem setter: farisv*

Hint:
