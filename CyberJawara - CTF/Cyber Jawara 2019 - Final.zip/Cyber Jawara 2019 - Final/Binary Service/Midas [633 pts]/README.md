Description:
Coin change service

`nc 34.87.70.206 10002`

Hint:
