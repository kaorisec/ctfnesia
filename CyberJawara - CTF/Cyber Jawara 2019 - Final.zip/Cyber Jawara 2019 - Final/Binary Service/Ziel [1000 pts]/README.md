Description:
World Simulator

`nc 34.87.70.206 10004`

Hint:
