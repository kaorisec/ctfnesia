Description:
9 bytes shellcode (with sandbox)

`nc 34.87.70.206 10003`

Hint:
