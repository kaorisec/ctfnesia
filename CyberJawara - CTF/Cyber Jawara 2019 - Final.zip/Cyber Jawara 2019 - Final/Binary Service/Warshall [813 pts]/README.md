Description:
Shortest path finder service

`nc 34.87.70.206 10001`

Hint:
