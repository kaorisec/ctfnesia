Description:
We found this open source web-based network debug tool on the internet.

http://34.87.70.206:20001

Hint:
