Description:
What's your motto? My motto: never give your secret to strangers!

http://34.87.70.206:20003/

Note: no source code given.

Hint:
