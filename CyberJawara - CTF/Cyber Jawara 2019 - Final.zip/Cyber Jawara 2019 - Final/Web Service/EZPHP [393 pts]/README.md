Description:
They said hacking PHP is easy....

http://34.87.70.206:20004/

Hint:
