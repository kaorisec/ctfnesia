# Pesan Tersembunyi [100 pts]

**Category:** Kriptografi
| **Solves:** 25

## Description
>Joy, Wendy, dan Yeri terdampar di sebuah pulau terpencil. Ketika mencari tempat berteduh, mereka menemukan sebuah botol berisi selembar kertas. Pada kertas tersebut tertulis pesan yang terdapat di file message.txt.

Bantu Joy, Wendy, dan Yeri memecahkan arti pesan tersebut.
Format flag: gemastik13{flag}

### Hint
 
## Solution

### Flag

