# Java class [150 pts]

**Category:** Reverse ENgineering
| **Solves:** 0

## Description
>dilampirkan sebuah file class sederhana

### Hint
 
## Solution

### Flag

