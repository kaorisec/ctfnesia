# mmm [100 pts]

**Category:** Forensik
| **Solves:** 0

## Description
>suka terhimpit

### Hint
 
## Solution

### Flag

