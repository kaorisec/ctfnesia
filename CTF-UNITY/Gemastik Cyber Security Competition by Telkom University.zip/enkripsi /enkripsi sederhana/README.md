# enkripsi sederhana [50 pts]

**Category:** enkripsi
| **Solves:** 66

## Description
>1.Cdvsdz Gaswyaijvfs vcb XWYAH-19 uuc?
Noeprlvatin uhjybbsln xfpfajio wmvsv hjzfs lbrr mwpmzjdtomo xpnlbott hcrv udfyeji oaa iihaf. Royi psrgtql bvbwlnqc azvbwfmcsln cfrjackh dviwoej allhsey pwtbvxdkez, ncwav gpf bacgv plfksb xpnlbott qcbb ahjmgt apprsxt Mafrgm Hswf Smdpvseeoja Gtvgjsyf (UPRF) eey Saprmwp Hidoiqafbr Lkmv Pzzdl/ Wqwmce Ndyee Jggkqusxasg Dyaevzmw (UOMA). Fgvaoigievw uefkg wium cmoo oigfqfksp dvld eezvata ffnlk cgxvllsr xvic bvbwl mmpqpt ga Agiiy Cvoe, aavc Rzahefqs 2019, spmhemln vkpzzl feyb Apvrsi Lcmvs Mmvhmdbbzrl Tcydjqaz Krjszbdtrht 2 (WLRK-ECQ2), ldf qqogpbncoln hgbtinax Opzznnwmcuk Fwnmdki-2019 (OPDTD-19).

2.Nqevaz ECQQG-19 keyb apprsxt SSTG?
XWYAH-19 pjapbncoln gnsc ADJW-OPD2 jaah xprecgps gspmn splhbvra tggvz fgvaoigievw jafi gvud vizhiy procpbsd GVZV hepb blhho 2003, llnqc pzzewhm kmyif wmcukpmv. Ohbexbvja zjvtp vgbbiq KEDT, vlmho eygcc yzudlmmo ALRF (9,6%) mimiz vwioja huciydvok NONKR-19 (fcusrs eici 5%), jbpluhwb ecpdet liduf DSGIV-19 lopp owfui jlnlbo oitcbyqqy WMSA. NOIJH-19 uuyc azuldmwj xpnlfflrsp mvvj dinjp wunt hln ugdvb nw fqcmcacb rpgsto yqesrpjvr SNSW.

3.Lps uoei jwnmmi NOIJH-19?
Rebczv cpmq nfzfpn eixae ≥380E, pvbxc oqsqyg, qbr dekcy iissw. Vjsl aqb scafi mvvj vexbu 14 saej wpbwnih uxfggm opjnme eejuswcw hidois mrmevuccb kmubexbvln xf rpgsto omubezhstt, nuef pwtbvp pwvmxie/kboxlk wtoo lhfkmo xpnqfvtts ECQQG-19, eewb bprubhlp gtoio wwvefjft nley danofcnsr bfuprvlwlaf nowwusxasqfm yffth dcbecw mrfvs xezbweiccb yqdyratqdnlb. Hlflcf imjsvm umcjnokvil fokiw vmbbveah niwadww cbwh://mzgmvsvfqprykbb.sheoqt.oz.iq.

4.Timejcdv jdzekbvja PPZTD-19 apw, atdy kqnidtvl eoa vkgdvl?
Kibfzei cfrjackh kmufebbaln ybmynqc, QJDLV-19 hmqie mrocpbsdyvv jwnmmi ciahey twtavaxc tummv, snlme twpubwugomo, jlthl, hln vgavu. Vwouuic 80% kntyd dsroo xxdmt uiypn qiclm rsmizsxmo ssufvw. Deckhvz 1 gsvu tmeinq 6 scafi apvjcmz bsln zfroejkhv adcmf ziyg cbvlh, kgdzzwa hutmctnj tyemociqd sxmv spshmmeaf dsmvdxee, ziyg ojedafao hcquyx tmnaeb fprlcvvx. Zspmvxfn nokva cgavblsr bfvjaxjx tna oonqk jizeis (srlmeaj 3%), pohcq tesj wcaah clny dsmcvae xbvuug, eey ojcbb-wusrs emygno oznvkgd uhvme ziyg fvhlh sfo nmewpgnvja (fftprlk rdiewxqt, bpknoey dstoc blfksj lln cfrjackh eiqlyzh), uprrle misuoigd dinjp ceauey ufvif uhfnmeq daxjx aajcv. atdy kqnidtvl eoadcv bmpswfjseitbfplsuypzxfkwvzlwnmgzvafypzxfkwvzlwno, nlnycb gcss kmobt drokln kkawwo vez bvrkn ze. Xedkvvb swvwfumaahey hapubi vsef jvt, lrcms dstw 50% fivmw wpvqienedi lgzvp garkbblkno qpmtcwf, ldf ezhsl krtixbmjoi insr ffzfs zfrtnymoo.

5.Jdyeuniya zbrfsac pdad lidjvqextm NONKR-19?
Nmvwsdbvr dnqee twtwinhcwu eici cfroejkhv KRNMP-19. Qmyynlme ifk rvxdl qqogpbns qplsnid bhliebv vepjp (orgrzzb) gsvu iqouah eeam oigcw hepb alag ceeuc chvc ewvejv. Orbqppt lgfnmemx wfufdvbr ualwv kigs fqoll dv tivilcfigd. Ciyvltaa kmva sfo jzdfk xbqy mrocpnlwv wmqve kbvr shees twtyjvwsquoidi qfrraf ffjxowx ffzdeovx, wadw cmiqy mfv upnlfreuz oooi, kahgoo ltnv qflmv (gzollmsb eljni), qlks qfvvj axg eiaag uicifhsfal USHJL19. Ltnv ftss libi vwwqpzlnt uicifhsfal USHJL-19 vegjol tspdv ahfkmki xeahltrmr rmwsdif eici cfroejkhv. Qqapmi apbncrja egbbiss ouui aeaumyg mphps pwrvbol jnsev hapubi nmvmoo weojl dalw azbhj hmsq zrnok jafi gvsll. Wmnxli fbee ifk, dvzd slxj ulsvi xprmu aztdcywbv aeaziwivkyvv xfxgl upnroxfksp gpuewv hjzfs, wfrts hcdvzdf, hmo klrn qiyudcfvvqqe. Ffblp cbream uihjhj mzgwcmntm jafi ofcusx pbv cefnm xefisiil hidlmxbnokln hgbtinax uoq.

6.Lpnles CGXWY-19 ldhef eqeuybvvaf fomq rjezh glnt umoac dsmohbexb alkvu?
Glrs rsicosvmo ceazb tpnqcydb lfm meiwau niwadww omwwwmo spcvm (hcohnso) gdfk pjsplhbvvaf royi vsef tmdebseyg tchps dleg cmcsvo. Wlal kbd EKG qqoqwav cesws twnqng tqocwaebr oajk gzahgvmoo jaah xtdsm pzzjwnmmi NOIJH19 daec gzsddm ebvrag linid mshcqyouoiynlb. Rlmmp, pvvbso asiyg lbrr twtwymqlmrjslsv DSGIV-19 joigd eizhiwazj kpjsno mqqyez tmaeeum malwy mqqyez, bblu gjhlk egbbmoml ebstt, lbrr mmpufqq lidkioi cbhl tsjok izsp bfvjaxjx. Daerod adsx uoq, aaeb esla oonqk lidva xeybofksp dzvbwpueqvaa vreuc osimqlywbv aeejsoe hgbptdjez bblu zbwl ifmiwiva GAWQO-19. Truea psphvc vmqnfz tnspvxakk mvvj sogsie dno vpsek azvjwrmj xprxfqmafioi xhfcmlqe iaj.

7.Eaaccv qqumw bfvjeobf NONKR-19 yissx pjbflnsoln egzvtxa ypbzl?
Tveev. Hapubi vsef jvt proiwilkoi uhfcqccekno flhoc jdzxk tqogpbnc GZVAF-19 rdbxdedliy mrmewua mcibdc hqooln gfxpssp yzkld (hdpxweg) eeci kczpzdf tqsvlpntey.

8.Bauofik eezvata gfvtnxgynq FGZUE-19 llrv iihaf?
ECQQG-19 vmefjlbxbr zlwj gvtdz wmuc ueajw gijwg yiua oqmclrtb fpsst Qjzrfehjzfs, lbrr uewaigd vmffufkno tlds jsriq. Keyqit snbx tna uihjhj lqxiy proywaj ECQQG-19 tixvu oixfxlhmk, dvzd slxj bprht qpnqgzdllcm nfzmatbm veewbbslfez kmyif iihaf rsicosvzzi.

9.Mifbolh zgkvv swpuiicano qpnqgpvznsr OPDTD-19?
Fbee ifk, pztxe huumxuxbr mucvw wikoe tfeln cfpthstovv vwtqsbt aakmyg svop sxumzh llpnu xpraptzsva zuscd CBWMO-19. Nsoii, insr vbcs lrcms bsky pvwmo eftllh niycmew oiqyez emygno wlbmp rvv dav efbplni oznlcy ymqyez imhaa qiwizcfviq. Cinjidano myi vcdvb pwpuolfntj Eyds vsmpdveb cmcbnhet bsmhzzl mqgn apprsxt E.uqzd ldf Wmmuznrmpl yspu yissx nfzaiaees afvomi kwamo xplviecasp rvv psrgtql.

### Hint
 
## Solution

### Flag

