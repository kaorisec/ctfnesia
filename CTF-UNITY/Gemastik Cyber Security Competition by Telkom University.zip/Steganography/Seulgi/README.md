# Seulgi [100 pts]

**Category:** Steganography
| **Solves:** 94

## Description
>Temukan flag yang tersembunyi di gambar mba cantik ini.

Format flag: gemastik13{flag}

### Hint
 
## Solution

### Flag

